﻿//using System.Data;
//using System.Xml;
//using System.Xml.Linq;
//using InRule.Repository.Service.Data.Requests;
//using InRule.Runtime;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.Options;
//using SDKRunner573.Models;
//using Serilog;

//namespace SDKRunner573;
///// <summary>
///// Runs XML files against 5.7.3 SDK based on entries defined in the appsettings.json file.
///// </summary>
/////
///// 
//public interface ISDKTesting
//{
//    void Start();
//}

//public class SDKTesting : ISDKTesting
//{
//    public void Start()
//    {
//        SDKXpath();
//    }

//    void SDKXpath()
//    {

//    }
//}