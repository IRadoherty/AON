﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using SDKRunner573.Models;

//namespace SDKRunner573.Services
//{
//    public class GetFilesService
//    {
//        private static readonly AppSettings AppSettings = Program.AppSettings;

//        public Directories GetFiles(bool ruleApps, bool xmlFiles)
//        {
//            var directories = new Directories();
//            if (ruleApps == true)
//            {
//                var ruleAppDirectory = new DirectoryInfo(AppSettings.RuleAppPath);
//                directories.RuleApps = ruleAppDirectory.GetFiles("*.ruleappx*");
//            }

//            if (xmlFiles != true) return directories;
//            var xmlFileDirectory = new DirectoryInfo(AppSettings.XmlFilePath);
//            directories.XmlFiles = xmlFileDirectory.GetFiles("*.xml*");

//            return directories;
//        }
//    }
//}
