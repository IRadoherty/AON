﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Serilog;
//using InRule.Runtime;
//using SDKRunner573.Models;


//namespace SDKRunner573.Services
//{
//    public class PullRuleSets
//    {
//        private static readonly AppSettings AppSettings = Program.AppSettings;
//        public void PullRuleSetsService()
//        {
//            var directories = GetFiles(true, false);
//            var ruleAppKeys = AppSettings.RuleAppKeys;
//            foreach (var ruleApp in directories.RuleApps)
//            {
//                foreach (var ruleAppDef in from ruleAppKey in ruleAppKeys
//                                           where ruleApp.Name.Contains(ruleAppKey)
//                                           select ruleApp.FullName into ruleAppFile
//                                           select new FileSystemRuleApplicationReference(ruleAppFile) into ruleAppRef
//                                           select ruleAppRef.GetRuleApplicationDef())
//                {
//                    Log.Logger.Information("Entity and rules for: {ruleApp}", ruleApp.Name);
//                    foreach (var entity in ruleAppDef.Entities)
//                    {
//                        var e = (dynamic)entity;
//                        var ruleElements = e.RuleElements;
//                        foreach (var ruleElement in ruleElements)
//                        {
//                            var r = (dynamic)ruleElement;
//                            var path = r.AuthoringElementPath;
//                            Log.Logger.Information("entity.ruleset {path}", path);

//                        }
//                    }
//                }
//            }
//        }
//        public Directories GetFiles(bool ruleApps, bool xmlFiles)
//        {
//            var directories = new Directories();
//            if (ruleApps == true)
//            {
//                var ruleAppDirectory = new DirectoryInfo(AppSettings.RuleAppPath);
//                directories.RuleApps = ruleAppDirectory.GetFiles("*.ruleappx*");
//            }

//            if (xmlFiles != true) return directories;
//            var xmlFileDirectory = new DirectoryInfo(AppSettings.XmlFilePath);
//            directories.XmlFiles = xmlFileDirectory.GetFiles("*.xml*");

//            return directories;
//        }
//    }
//}
