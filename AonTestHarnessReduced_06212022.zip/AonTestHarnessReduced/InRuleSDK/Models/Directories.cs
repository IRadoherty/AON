﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKRunner573.Models
{
    public class Directories
    {
        public FileInfo[] RuleApps;
        public FileInfo[] XmlFiles;
    }
}
