﻿// using System.Xml.Serialization;
// XmlSerializer serializer = new XmlSerializer(typeof(POLICY));
// using (StringReader reader = new StringReader(xml))
// {
//    var test = (POLICY)serializer.Deserialize(reader);
// }


using System.Xml.Serialization;

public class RatingClass
{
    [XmlRoot(ElementName = "POLICY")]
    public class Rating
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "CONVERTED")]
        public int CONVERTED { get; set; }

        [XmlElement(ElementName = "EFFECTIVE_DATE")]
        public DateTime EFFECTIVEDATE { get; set; }

        [XmlElement(ElementName = "EXPIRATION_DATE")]
        public DateTime EXPIRATIONDATE { get; set; }

        [XmlElement(ElementName = "FILING_STATUS")]
        public string FILINGSTATUS { get; set; }

        [XmlElement(ElementName = "PROGRAM_POLICY_TYPE")]
        public int PROGRAMPOLICYTYPE { get; set; }

        [XmlElement(ElementName = "PROGRAM_NAME")]
        public string PROGRAMNAME { get; set; }

        [XmlElement(ElementName = "POLICY_NUMBER")]
        public string POLICYNUMBER { get; set; }

        [XmlElement(ElementName = "RATED")] public int RATED { get; set; }

        [XmlElement(ElementName = "RATING_DATE")]
        public DateTime RATINGDATE { get; set; }

        [XmlElement(ElementName = "TRANSACTION_TYPE")]
        public string TRANSACTIONTYPE { get; set; }

        [XmlElement(ElementName = "PROGRAM_TYPE")]
        public string PROGRAMTYPE { get; set; }

        [XmlElement(ElementName = "Is_Policy")]
        public int IsPolicy { get; set; }

        [XmlElement(ElementName = "PENDING_PRIOR_DATE")]
        public DateTime PENDINGPRIORDATE { get; set; }

        [XmlElement(ElementName = "EndorsesCount")]
        public int EndorsesCount { get; set; }

        [XmlElement(ElementName = "POLICY_AFF_DNO")]
        public POLICYAFFDNO POLICYAFFDNO { get; set; }

        [XmlElement(ElementName = "POLICY_COVERAGE")]
        public List<POLICYCOVERAGE> POLICYCOVERAGE { get; set; }

        [XmlElement(ElementName = "POLICY_SECTION")]
        public List<POLICYSECTION> POLICYSECTION { get; set; }

        [XmlElement(ElementName = "POLICY_LOCATION")]
        public POLICYLOCATION POLICYLOCATION { get; set; }

        [XmlElement(ElementName = "PROGRAM_SECTION_TABLE")]
        public PROGRAMSECTIONTABLE PROGRAMSECTIONTABLE { get; set; }

        [XmlElement(ElementName = "PROGRAM_COVERAGE_TABLE")]
        public PROGRAMCOVERAGETABLE PROGRAMCOVERAGETABLE { get; set; }

        [XmlElement(ElementName = "PROGRAM_POLICY_TYPE_TABLE")]
        public PROGRAMPOLICYTYPETABLE PROGRAMPOLICYTYPETABLE { get; set; }

        [XmlElement(ElementName = "PROGRAM_ADDL_INTEREST_TABLE")]
        public object PROGRAMADDLINTERESTTABLE { get; set; }

        [XmlElement(ElementName = "STATE")] public string STATE { get; set; }

        [XmlElement(ElementName = "PROGRAM")] public int PROGRAM { get; set; }

        [XmlElement(ElementName = "INSURED_NAME")]
        public string INSUREDNAME { get; set; }

        [XmlElement(ElementName = "TERM_FACTOR")]
        public int TERMFACTOR { get; set; }

        [XmlElement(ElementName = "PRORATA_FACTOR")]
        public int PRORATAFACTOR { get; set; }

        [XmlElement(ElementName = "USERID")] public string USERID { get; set; }
    }



    [XmlRoot(ElementName = "POLICY_AFF_DNO_DOEPL")]
    public class POLICYAFFDNODOEPL
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "AM_ACCREDIATION")]
        public int AMACCREDIATION { get; set; }

        [XmlElement(ElementName = "AM_PEER_REVIEW")]
        public int AMPEERREVIEW { get; set; }

        [XmlElement(ElementName = "AM_SIGNIFICANT_CONV")]
        public int AMSIGNIFICANTCONV { get; set; }

        [XmlElement(ElementName = "AM_STANDARD_SETTING")]
        public int AMSTANDARDSETTING { get; set; }

        [XmlElement(ElementName = "COC_PROVIDE_LOANS_Q")]
        public int COCPROVIDELOANSQ { get; set; }

        [XmlElement(ElementName = "CYBER_COV")]
        public int CYBERCOV { get; set; }

        [XmlElement(ElementName = "CYBER_COV_PREMIUM")]
        public double CYBERCOVPREMIUM { get; set; }

        [XmlElement(ElementName = "DED_FACTOR")]
        public double DEDFACTOR { get; set; }

        [XmlElement(ElementName = "DEFENSE_OUTSIDE_FACTOR")]
        public int DEFENSEOUTSIDEFACTOR { get; set; }

        [XmlElement(ElementName = "FLSA_SUBLIMIT")]
        public int FLSASUBLIMIT { get; set; }

        [XmlElement(ElementName = "FLSA_SUBLIMIT_PREMIUM")]
        public double FLSASUBLIMITPREMIUM { get; set; }

        [XmlElement(ElementName = "FM_MEMBER_OF_COUNCIL")]
        public int FMMEMBEROFCOUNCIL { get; set; }

        [XmlElement(ElementName = "FM_MEMBER_OF_COUNCIL_Q")]
        public int FMMEMBEROFCOUNCILQ { get; set; }

        [XmlElement(ElementName = "FM_NON_GRANT_MAKING")]
        public int FMNONGRANTMAKING { get; set; }

        [XmlElement(ElementName = "FM_NON_GRANT_MAKING_Q")]
        public int FMNONGRANTMAKINGQ { get; set; }

        [XmlElement(ElementName = "IRM_FINANCIAL_COND")]
        public int IRMFINANCIALCOND { get; set; }

        [XmlElement(ElementName = "IRM_MGMT_EXP")]
        public int IRMMGMTEXP { get; set; }

        [XmlElement(ElementName = "IRM_NATURE_OF_OPS")]
        public int IRMNATUREOFOPS { get; set; }

        [XmlElement(ElementName = "LIMIT")] public int LIMIT { get; set; }

        [XmlElement(ElementName = "LIMITS_FACTOR")]
        public double LIMITSFACTOR { get; set; }

        [XmlElement(ElementName = "MM_MEMBER_OF_AOM")]
        public int MMMEMBEROFAOM { get; set; }

        [XmlElement(ElementName = "PM_CLAIMS_EXP")]
        public double PMCLAIMSEXP { get; set; }

        [XmlElement(ElementName = "PM_CLAIMS_NON_EXP")]
        public int PMCLAIMSNONEXP { get; set; }

        [XmlElement(ElementName = "PM_CORP_GOV")]
        public int PMCORPGOV { get; set; }

        [XmlElement(ElementName = "PM_EMPLOYEE_TURNOVER")]
        public int PMEMPLOYEETURNOVER { get; set; }

        [XmlElement(ElementName = "PM_NUM_EMPLOYEES_FACTOR")]
        public int PMNUMEMPLOYEESFACTOR { get; set; }

        [XmlElement(ElementName = "PM_WRITTEN_HR_PROC")]
        public int PMWRITTENHRPROC { get; set; }

        [XmlElement(ElementName = "PREMIUM")] public int PREMIUM { get; set; }

        [XmlElement(ElementName = "PRIOR_KNOWLEDGE_Q")]
        public int PRIORKNOWLEDGEQ { get; set; }

        [XmlElement(ElementName = "SEPERATE_LIMITS")]
        public int SEPERATELIMITS { get; set; }

        [XmlElement(ElementName = "SEPERATE_LIMITS_FACTOR")]
        public int SEPERATELIMITSFACTOR { get; set; }

        [XmlElement(ElementName = "TOTAL_IRM")]
        public int TOTALIRM { get; set; }

        [XmlElement(ElementName = "UWM_RELY_ON_GOV_FUND")]
        public int UWMRELYONGOVFUND { get; set; }

        [XmlElement(ElementName = "UWM_RELY_ON_GOV_FUND_Q")]
        public int UWMRELYONGOVFUNDQ { get; set; }

        [XmlElement(ElementName = "UWM_STABILITT_OF_REV")]
        public int UWMSTABILITTOFREV { get; set; }

        [XmlElement(ElementName = "UWM_STABILITT_OF_REV_Q")]
        public int UWMSTABILITTOFREVQ { get; set; }

        [XmlElement(ElementName = "UWM_WORK_WITH_CHILDREN")]
        public int UWMWORKWITHCHILDREN { get; set; }

        [XmlElement(ElementName = "UWM_WORK_WITH_CHILDREN_Q")]
        public int UWMWORKWITHCHILDRENQ { get; set; }

        [XmlElement(ElementName = "UWM_WORK_WITH_HANDICAP")]
        public int UWMWORKWITHHANDICAP { get; set; }

        [XmlElement(ElementName = "UWM_WORK_WITH_HANDICAP_Q")]
        public int UWMWORKWITHHANDICAPQ { get; set; }

        [XmlElement(ElementName = "WV_ENDTYPE")]
        public int WVENDTYPE { get; set; }

        [XmlElement(ElementName = "DO_RISK_GRP")]
        public string DORISKGRP { get; set; }

        [XmlElement(ElementName = "DO_RISK_GRP_FACTOR")]
        public double DORISKGRPFACTOR { get; set; }

        [XmlElement(ElementName = "DO_MGMT_STABILITY")]
        public string DOMGMTSTABILITY { get; set; }

        [XmlElement(ElementName = "MGMT_STABILITY_MOD")]
        public double MGMTSTABILITYMOD { get; set; }

        [XmlElement(ElementName = "DO_QLTY_BAL_SHEET")]
        public string DOQLTYBALSHEET { get; set; }

        [XmlElement(ElementName = "QLTY_BAL_SHEET_MOD")]
        public double QLTYBALSHEETMOD { get; set; }

        [XmlElement(ElementName = "DO_FIN_STABILITY")]
        public string DOFINSTABILITY { get; set; }

        [XmlElement(ElementName = "FIN_STABILITY_MOD")]
        public double FINSTABILITYMOD { get; set; }

        [XmlElement(ElementName = "DO_MGMT_QLTY")]
        public string DOMGMTQLTY { get; set; }

        [XmlElement(ElementName = "MGMT_QLTY_MOD")]
        public double MGMTQLTYMOD { get; set; }

        [XmlElement(ElementName = "DO_RISK_COMPLEXITY")]
        public string DORISKCOMPLEXITY { get; set; }

        [XmlElement(ElementName = "DO_RISK_COMPLEXITY_MOD")]
        public double DORISKCOMPLEXITYMOD { get; set; }

        [XmlElement(ElementName = "ADD_DO_LIMIT_LIAB_Q")]
        public int ADDDOLIMITLIABQ { get; set; }

        [XmlElement(ElementName = "DO_ADDL_LIMIT_LIAB")]
        public double DOADDLLIMITLIAB { get; set; }

        [XmlElement(ElementName = "ADD_EPL_Q")]
        public int ADDEPLQ { get; set; }

        [XmlElement(ElementName = "EPL_PREMIUM")]
        public double EPLPREMIUM { get; set; }

        [XmlElement(ElementName = "EPL_LIMIT")]
        public double EPLLIMIT { get; set; }

        [XmlElement(ElementName = "EPL_LIMIT_FACTOR")]
        public double EPLLIMITFACTOR { get; set; }

        [XmlElement(ElementName = "EPL_DEDUCTIBLE")]
        public double EPLDEDUCTIBLE { get; set; }

        [XmlElement(ElementName = "EPL_DED_FACTOR")]
        public double EPLDEDFACTOR { get; set; }

        [XmlElement(ElementName = "EPL_CA_EXPOSURE")]
        public double EPLCAEXPOSURE { get; set; }

        [XmlElement(ElementName = "EPL_CA_EXPOSURE_MOD")]
        public double EPLCAEXPOSUREMOD { get; set; }

        [XmlElement(ElementName = "EPL_RISK_GRP")]
        public string EPLRISKGRP { get; set; }

        [XmlElement(ElementName = "EPL_RISK_GRP_FACTOR")]
        public double EPLRISKGRPFACTOR { get; set; }

        [XmlElement(ElementName = "EPL_PRIOR_CLAIMS")]
        public string EPLPRIORCLAIMS { get; set; }

        [XmlElement(ElementName = "EPL_PRIOR_CLAIMS_MOD")]
        public double EPLPRIORCLAIMSMOD { get; set; }

        [XmlElement(ElementName = "EPL_RISK_COMPLEXITY")]
        public string EPLRISKCOMPLEXITY { get; set; }

        [XmlElement(ElementName = "EPL_RISK_COMPLEXITY_MOD")]
        public double EPLRISKCOMPLEXITYMOD { get; set; }

        [XmlElement(ElementName = "DO_YEARS_IN_OP_MOD")]
        public double DOYEARSINOPMOD { get; set; }

        [XmlElement(ElementName = "DO_PRIOR_CLAIMS")]
        public string DOPRIORCLAIMS { get; set; }

        [XmlElement(ElementName = "EPL_YEARS_IN_OP_MOD")]
        public double EPLYEARSINOPMOD { get; set; }

        [XmlElement(ElementName = "EPL_EMPLOYEE_TURNOVER")]
        public string EPLEMPLOYEETURNOVER { get; set; }

        [XmlElement(ElementName = "EPL_EMPLOY_DIVERSITY")]
        public string EPLEMPLOYDIVERSITY { get; set; }

        [XmlElement(ElementName = "EPL_EMPLOY_DIVERSITY_MOD")]
        public double EPLEMPLOYDIVERSITYMOD { get; set; }

        [XmlElement(ElementName = "EPL_HUMAN_RESOURCE")]
        public string EPLHUMANRESOURCE { get; set; }

        [XmlElement(ElementName = "EPL_HUMAN_RESOURCE_MOD")]
        public double EPLHUMANRESOURCEMOD { get; set; }

        [XmlElement(ElementName = "EPL_SALARY_RANGE")]
        public string EPLSALARYRANGE { get; set; }

        [XmlElement(ElementName = "EPL_SALARY_RANGE_MOD")]
        public double EPLSALARYRANGEMOD { get; set; }

        [XmlElement(ElementName = "ADD_THIRD_PARTY_Q")]
        public int ADDTHIRDPARTYQ { get; set; }

        [XmlElement(ElementName = "THIRD_PARTY_FACTOR")]
        public double THIRDPARTYFACTOR { get; set; }

        [XmlElement(ElementName = "THIRD_PARTY")]
        public string THIRDPARTY { get; set; }

        [XmlElement(ElementName = "EXPENSE_MOD_Q")]
        public int EXPENSEMODQ { get; set; }

        [XmlElement(ElementName = "EXPENSE_MOD_CHARGE")]
        public double EXPENSEMODCHARGE { get; set; }

        [XmlElement(ElementName = "SHARED_LIMIT_DISCOUNT")]
        public double SHAREDLIMITDISCOUNT { get; set; }

        [XmlElement(ElementName = "BASE_RATE")]
        public double BASERATE { get; set; }

        [XmlElement(ElementName = "EPL_BASE_RATE")]
        public double EPLBASERATE { get; set; }

        [XmlElement(ElementName = "EPL_PP_DATE")]
        public DateTime EPLPPDATE { get; set; }

        [XmlElement(ElementName = "CRISIS_MGMNT_SUBLIMIT")]
        public double CRISISMGMNTSUBLIMIT { get; set; }

        [XmlElement(ElementName = "ADDTL_LIAB_MGRS_SUBLIMIT")]
        public double ADDTLLIABMGRSSUBLIMIT { get; set; }

        [XmlElement(ElementName = "EMTALA_SUBLIMIT")]
        public double EMTALASUBLIMIT { get; set; }

        [XmlElement(ElementName = "HIPAA_SUBLIMIT")]
        public double HIPAASUBLIMIT { get; set; }

        [XmlElement(ElementName = "SEX_MISCONDUCT_SUBLIMIT")]
        public double SEXMISCONDUCTSUBLIMIT { get; set; }

        [XmlElement(ElementName = "DO_TOTAL_MOD")]
        public double DOTOTALMOD { get; set; }

        [XmlElement(ElementName = "EPL_TOTAL_MOD")]
        public double EPLTOTALMOD { get; set; }

        [XmlElement(ElementName = "PREMIUM_PR")]
        public double PREMIUMPR { get; set; }

        [XmlElement(ElementName = "EPL_PREMIUM_PR")]
        public double EPLPREMIUMPR { get; set; }

        [XmlElement(ElementName = "EPL_YEARS_IN_OP")]
        public string EPLYEARSINOP { get; set; }

        [XmlElement(ElementName = "DO_YEARS_IN_OP")]
        public string DOYEARSINOP { get; set; }

        [XmlElement(ElementName = "THIRD_PARTY_LIMIT")]
        public double THIRDPARTYLIMIT { get; set; }

        [XmlElement(ElementName = "THIRD_PARTY_DEDUCTIBLE")]
        public double THIRDPARTYDEDUCTIBLE { get; set; }

        [XmlElement(ElementName = "THIRD_PARTY_PP_LIT_DATE")]
        public DateTime THIRDPARTYPPLITDATE { get; set; }

        [XmlElement(ElementName = "OVERRIDE_DO_PREM")]
        public int OVERRIDEDOPREM { get; set; }

        [XmlElement(ElementName = "OVERRIDE_EPL_PREM")]
        public int OVERRIDEEPLPREM { get; set; }

        [XmlElement(ElementName = "EPL_PT_EMPLOY_FACTOR")]
        public double EPLPTEMPLOYFACTOR { get; set; }

        [XmlElement(ElementName = "WV_DEDUCTIBLE")]
        public double WVDEDUCTIBLE { get; set; }

        [XmlElement(ElementName = "DO_DEF_COST_FACTOR")]
        public double DODEFCOSTFACTOR { get; set; }

        [XmlElement(ElementName = "EPL_DEF_COST_FACTOR")]
        public double EPLDEFCOSTFACTOR { get; set; }

        [XmlElement(ElementName = "DO_DEF_COST_PREMIUM")]
        public double DODEFCOSTPREMIUM { get; set; }

        [XmlElement(ElementName = "EPL_DEF_COST_PREMIUM")]
        public double EPLDEFCOSTPREMIUM { get; set; }

        [XmlElement(ElementName = "DO_LD_FACTOR")]
        public double DOLDFACTOR { get; set; }

        [XmlElement(ElementName = "EPL_LD_FACTOR")]
        public double EPLLDFACTOR { get; set; }

        [XmlElement(ElementName = "DO_STATE_SCHEDULE_MOD")]
        public double DOSTATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "EPL_STATE_SCHEDULE_MOD")]
        public double EPLSTATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "ANTI_TRUST_LIMIT")]
        public int ANTITRUSTLIMIT { get; set; }

        [XmlElement(ElementName = "ACCREDITATION_LIMIT")]
        public int ACCREDITATIONLIMIT { get; set; }

        [XmlElement(ElementName = "PROVENANCE_LIMIT")]
        public int PROVENANCELIMIT { get; set; }

        [XmlElement(ElementName = "ADD_ANTI_TRUST_Q")]
        public int ADDANTITRUSTQ { get; set; }

        [XmlElement(ElementName = "ADD_ACCREDITATION_Q")]
        public int ADDACCREDITATIONQ { get; set; }

        [XmlElement(ElementName = "ADD_PROVENANCE_Q")]
        public int ADDPROVENANCEQ { get; set; }

        [XmlElement(ElementName = "PROVENANCE_MOD")]
        public double PROVENANCEMOD { get; set; }

        [XmlElement(ElementName = "MM_MEMBER_OF_AOM_Q")]
        public int MMMEMBEROFAOMQ { get; set; }

        [XmlElement(ElementName = "DO_BASE_PREMIUM")]
        public double DOBASEPREMIUM { get; set; }

        [XmlElement(ElementName = "EPL_BASE_PREMIUM")]
        public double EPLBASEPREMIUM { get; set; }

        [XmlElement(ElementName = "AM_STANDARD_SETTING_LIST")]
        public string AMSTANDARDSETTINGLIST { get; set; }
    }

    [XmlRoot(ElementName = "POLICY_AFF_DNO_FID")]
    public class POLICYAFFDNOFID
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "BASE_PREMIUM")]
        public int BASEPREMIUM { get; set; }

        [XmlElement(ElementName = "BLENDING_CREDIT")]
        public int BLENDINGCREDIT { get; set; }

        [XmlElement(ElementName = "COMBINED_DO_LIMIT")]
        public int COMBINEDDOLIMIT { get; set; }

        [XmlElement(ElementName = "DED_FACTOR")]
        public double DEDFACTOR { get; set; }

        [XmlElement(ElementName = "SHORT_TERM")]
        public int SHORTTERM { get; set; }

        [XmlElement(ElementName = "HIPPA_SUBLIMIT")]
        public int HIPPASUBLIMIT { get; set; }

        [XmlElement(ElementName = "IRM")] public int IRM { get; set; }

        [XmlElement(ElementName = "LIMIT")] public int LIMIT { get; set; }

        [XmlElement(ElementName = "LIMITS_FACTOR")]
        public double LIMITSFACTOR { get; set; }

        [XmlElement(ElementName = "PLAN_ASSET_CHARGE")]
        public int PLANASSETCHARGE { get; set; }

        [XmlElement(ElementName = "PLAN_ASSETS")]
        public int PLANASSETS { get; set; }

        [XmlElement(ElementName = "PM_DEFINED_BENEFIT")]
        public int PMDEFINEDBENEFIT { get; set; }

        [XmlElement(ElementName = "PM_DEFINED_BENEFIT_Q")]
        public int PMDEFINEDBENEFITQ { get; set; }

        [XmlElement(ElementName = "PM_ESOP")] public double PMESOP { get; set; }

        [XmlElement(ElementName = "PM_ESOP_Q")]
        public int PMESOPQ { get; set; }

        [XmlElement(ElementName = "PREMIUM")] public int PREMIUM { get; set; }

        [XmlElement(ElementName = "RETENTION")]
        public int RETENTION { get; set; }

        [XmlElement(ElementName = "SUPP_PROGRAM_COV")]
        public int SUPPPROGRAMCOV { get; set; }

        [XmlElement(ElementName = "SUPP_PROGRAM_COV_PREMIUM")]
        public int SUPPPROGRAMCOVPREMIUM { get; set; }

        [XmlElement(ElementName = "PLAN_REG_COMP")]
        public string PLANREGCOMP { get; set; }

        [XmlElement(ElementName = "PLAN_REG_COMP_MOD")]
        public double PLANREGCOMPMOD { get; set; }

        [XmlElement(ElementName = "BENEFIT_PLAN")]
        public string BENEFITPLAN { get; set; }

        [XmlElement(ElementName = "ESOP")] public string ESOP { get; set; }

        [XmlElement(ElementName = "PLAN_TERM")]
        public string PLANTERM { get; set; }

        [XmlElement(ElementName = "PLAN_TERM_MOD")]
        public double PLANTERMMOD { get; set; }

        [XmlElement(ElementName = "PLAN_MGMT")]
        public string PLANMGMT { get; set; }

        [XmlElement(ElementName = "PLAN_MGMT_MOD")]
        public double PLANMGMTMOD { get; set; }

        [XmlElement(ElementName = "PLAN_DIVERSITY")]
        public string PLANDIVERSITY { get; set; }

        [XmlElement(ElementName = "PLAN_DIVERSITY_MOD")]
        public double PLANDIVERSITYMOD { get; set; }

        [XmlElement(ElementName = "FUNDING")] public string FUNDING { get; set; }

        [XmlElement(ElementName = "FUNDING_MOD")]
        public double FUNDINGMOD { get; set; }

        [XmlElement(ElementName = "FINANCIAL_STABILITY")]
        public string FINANCIALSTABILITY { get; set; }

        [XmlElement(ElementName = "FINANCIAL_STABILITY_MOD")]
        public double FINANCIALSTABILITYMOD { get; set; }

        [XmlElement(ElementName = "MGMT_QLTY")]
        public string MGMTQLTY { get; set; }

        [XmlElement(ElementName = "MGMT_QLTY_MOD")]
        public double MGMTQLTYMOD { get; set; }

        [XmlElement(ElementName = "YEARS_IN_BUSN")]
        public string YEARSINBUSN { get; set; }

        [XmlElement(ElementName = "YEARS_IN_BUSN_MOD")]
        public double YEARSINBUSNMOD { get; set; }

        [XmlElement(ElementName = "MERGER_ACQUISITION")]
        public string MERGERACQUISITION { get; set; }

        [XmlElement(ElementName = "MERGER_ACQUISITION_MOD")]
        public double MERGERACQUISITIONMOD { get; set; }

        [XmlElement(ElementName = "RISK_COMPLEXITY")]
        public string RISKCOMPLEXITY { get; set; }

        [XmlElement(ElementName = "RISK_COMPLEXITY_MOD")]
        public double RISKCOMPLEXITYMOD { get; set; }

        [XmlElement(ElementName = "UW_INTENSITY")]
        public string UWINTENSITY { get; set; }

        [XmlElement(ElementName = "UW_INTENSITY_MOD")]
        public double UWINTENSITYMOD { get; set; }

        [XmlElement(ElementName = "PPACA_SUBLIMIT")]
        public double PPACASUBLIMIT { get; set; }

        [XmlElement(ElementName = "TOTAL_MOD")]
        public double TOTALMOD { get; set; }

        [XmlElement(ElementName = "PRIOR_CLAIMS")]
        public string PRIORCLAIMS { get; set; }

        [XmlElement(ElementName = "PRIOR_CLAIMS_MOD")]
        public double PRIORCLAIMSMOD { get; set; }

        [XmlElement(ElementName = "PREMIUM_PR")]
        public double PREMIUMPR { get; set; }

        [XmlElement(ElementName = "OVERRIDE_FID_PREM")]
        public int OVERRIDEFIDPREM { get; set; }

        [XmlElement(ElementName = "DEF_COST_FACTOR")]
        public double DEFCOSTFACTOR { get; set; }

        [XmlElement(ElementName = "DEF_COST_PREMIUM")]
        public double DEFCOSTPREMIUM { get; set; }

        [XmlElement(ElementName = "FID_LD_FACTOR")]
        public double FIDLDFACTOR { get; set; }

        [XmlElement(ElementName = "STATE_SCHEDULE_MOD")]
        public double STATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "FID_BASE_PREMIUM")]
        public double FIDBASEPREMIUM { get; set; }
    }

    [XmlRoot(ElementName = "POLICY_AFF_DNO_CRIME")]
    public class POLICYAFFDNOCRIME
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "ADD_SCHED_EXC_LIMIT")]
        public int ADDSCHEDEXCLIMIT { get; set; }

        [XmlElement(ElementName = "ADDL_LOCATION_CHARGE")]
        public int ADDLLOCATIONCHARGE { get; set; }

        [XmlElement(ElementName = "AGGREGATE_LIMIT_OF_INS")]
        public double AGGREGATELIMITOFINS { get; set; }

        [XmlElement(ElementName = "AMEND_FORGE_PER_OCC")]
        public int AMENDFORGEPEROCC { get; set; }

        [XmlElement(ElementName = "AMEND_GEN_COND_G")]
        public int AMENDGENCONDG { get; set; }

        [XmlElement(ElementName = "AMEND_GEN_COND_H_LIMIT")]
        public int AMENDGENCONDHLIMIT { get; set; }

        [XmlElement(ElementName = "AMEND_GEN_COND_I_LIMIT")]
        public int AMENDGENCONDILIMIT { get; set; }

        [XmlElement(ElementName = "AMEND_INSURING_AGGR_2")]
        public int AMENDINSURINGAGGR2 { get; set; }

        [XmlElement(ElementName = "AUDIT_CONTROLS")]
        public string AUDITCONTROLS { get; set; }

        [XmlElement(ElementName = "BACKGROUND_CHECKS")]
        public string BACKGROUNDCHECKS { get; set; }

        [XmlElement(ElementName = "BASE_PREMIUM")]
        public int BASEPREMIUM { get; set; }

        [XmlElement(ElementName = "CARD_FORGE_FULL_LIMIT")]
        public int CARDFORGEFULLLIMIT { get; set; }

        [XmlElement(ElementName = "CFRAUD_COV_PART_PREMIUM")]
        public int CFRAUDCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "COMP_FRAUD_LD_FACTOR")]
        public double COMPFRAUDLDFACTOR { get; set; }

        [XmlElement(ElementName = "COMP_FRAUD_LIMIT")]
        public int COMPFRAUDLIMIT { get; set; }

        [XmlElement(ElementName = "COMP_FRAUD_RETENTION")]
        public int COMPFRAUDRETENTION { get; set; }

        [XmlElement(ElementName = "CRIME_AGGREGATE_LIMIT")]
        public double CRIMEAGGREGATELIMIT { get; set; }

        [XmlElement(ElementName = "END_ADD_SCHED_EXC_LIMIT")]
        public int ENDADDSCHEDEXCLIMIT { get; set; }

        [XmlElement(ElementName = "END_AGGREATE_LIMIT_OF_INS")]
        public int ENDAGGREATELIMITOFINS { get; set; }

        [XmlElement(ElementName = "END_AMEND_FORGE_PER_OCC")]
        public int ENDAMENDFORGEPEROCC { get; set; }

        [XmlElement(ElementName = "END_AMEND_GEN_COND_G")]
        public int ENDAMENDGENCONDG { get; set; }

        [XmlElement(ElementName = "END_AMEND_INSURIGN_AGGR_2")]
        public int ENDAMENDINSURIGNAGGR2 { get; set; }

        [XmlElement(ElementName = "END_CARD_FORGE_FULL_LIMIT")]
        public int ENDCARDFORGEFULLLIMIT { get; set; }

        [XmlElement(ElementName = "END_INCL_DESIGNATED_AGENTS")]
        public int ENDINCLDESIGNATEDAGENTS { get; set; }

        [XmlElement(ElementName = "END_LIMIT_AMT_TRADING_LOSS")]
        public int ENDLIMITAMTTRADINGLOSS { get; set; }

        [XmlElement(ElementName = "END_LOSS_SUSTAINED_COV")]
        public int ENDLOSSSUSTAINEDCOV { get; set; }

        [XmlElement(ElementName = "END_THEFT_PROP_WITH_CLAUSE")]
        public int ENDTHEFTPROPWITHCLAUSE { get; set; }

        [XmlElement(ElementName = "END_THEFT_PROP_WO_CLAUSE")]
        public int ENDTHEFTPROPWOCLAUSE { get; set; }

        [XmlElement(ElementName = "FINAL_CFRAUD_COV_PART_PREMIUM")]
        public int FINALCFRAUDCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "FINAL_FORGERY_COV_PART_PREMIUM")]
        public int FINALFORGERYCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "FINAL_INS_MSP_COV_PART_PREMIUM")]
        public int FINALINSMSPCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "FINAL_OUT_MSP_COV_PART_PREMIUM")]
        public int FINALOUTMSPCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "FINAL_THEFT_COV_PART_PREMIUM")]
        public int FINALTHEFTCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "FOREIGN_EXPOSURE")]
        public string FOREIGNEXPOSURE { get; set; }

        [XmlElement(ElementName = "FORGERY_COV_PART_PREMIUM")]
        public int FORGERYCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "FORGERY_LD_FACTOR")]
        public int FORGERYLDFACTOR { get; set; }

        [XmlElement(ElementName = "FORGERY_LIMIT")]
        public int FORGERYLIMIT { get; set; }

        [XmlElement(ElementName = "FORGERY_RETENTION")]
        public int FORGERYRETENTION { get; set; }

        [XmlElement(ElementName = "HIGH_VALUE_INVENTORY")]
        public string HIGHVALUEINVENTORY { get; set; }

        [XmlElement(ElementName = "INCL_DESIGNATED_AGENTS")]
        public int INCLDESIGNATEDAGENTS { get; set; }

        [XmlElement(ElementName = "INCREASE_SPEC_PER_INS_MSP")]
        public int INCREASESPECPERINSMSP { get; set; }

        [XmlElement(ElementName = "INCREASE_SPEC_PER_LIMIT")]
        public int INCREASESPECPERLIMIT { get; set; }

        [XmlElement(ElementName = "INCREASE_SPEC_PET_OUT_MSP")]
        public int INCREASESPECPETOUTMSP { get; set; }

        [XmlElement(ElementName = "INDUSTRY_FACTOR")]
        public int INDUSTRYFACTOR { get; set; }

        [XmlElement(ElementName = "INS_MSP_COV_PART_PREMIUM")]
        public int INSMSPCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "INS_MSP_LD_FACTOR")]
        public double INSMSPLDFACTOR { get; set; }

        [XmlElement(ElementName = "INS_MSP_LIMIT")]
        public int INSMSPLIMIT { get; set; }

        [XmlElement(ElementName = "INS_MSP_RETENTION")]
        public int INSMSPRETENTION { get; set; }

        [XmlElement(ElementName = "LIMIT_AMT_TRADING_LOSS")]
        public int LIMITAMTTRADINGLOSS { get; set; }

        [XmlElement(ElementName = "LOSS_ACTIVITY")]
        public string LOSSACTIVITY { get; set; }

        [XmlElement(ElementName = "LOSS_SUSTAINED_COV")]
        public int LOSSSUSTAINEDCOV { get; set; }

        [XmlElement(ElementName = "MIA_DISCOUNT")]
        public int MIADISCOUNT { get; set; }

        [XmlElement(ElementName = "NAIC_CODE")]
        public int NAICCODE { get; set; }

        [XmlElement(ElementName = "NUM_ADDL_LOCATIONS")]
        public int NUMADDLLOCATIONS { get; set; }

        [XmlElement(ElementName = "OUT_MSP_COV_PART_PREMIUM")]
        public int OUTMSPCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "OUT_MSP_LD_FACTOR")]
        public double OUTMSPLDFACTOR { get; set; }

        [XmlElement(ElementName = "OUT_MSP_LIMIT")]
        public int OUTMSPLIMIT { get; set; }

        [XmlElement(ElementName = "OUT_MSP_RETENTION")]
        public int OUTMSPRETENTION { get; set; }

        [XmlElement(ElementName = "PREMIUM")] public int PREMIUM { get; set; }

        [XmlElement(ElementName = "PURCHASING_VENDOR_CONTROLS")]
        public string PURCHASINGVENDORCONTROLS { get; set; }

        [XmlElement(ElementName = "REV_EMPLOYEE_MOD")]
        public int REVEMPLOYEEMOD { get; set; }

        [XmlElement(ElementName = "SHORT_TERM")]
        public int SHORTTERM { get; set; }

        [XmlElement(ElementName = "THEFT_COV_PART_PREMIUM")]
        public int THEFTCOVPARTPREMIUM { get; set; }

        [XmlElement(ElementName = "THEFT_LD_FACTOR")]
        public double THEFTLDFACTOR { get; set; }

        [XmlElement(ElementName = "THEFT_LIMIT")]
        public int THEFTLIMIT { get; set; }

        [XmlElement(ElementName = "THEFT_PROP_WITH_CLAUSE")]
        public int THEFTPROPWITHCLAUSE { get; set; }

        [XmlElement(ElementName = "THEFT_PROP_WO_CLAUSE")]
        public int THEFTPROPWOCLAUSE { get; set; }

        [XmlElement(ElementName = "THEFT_RETENTION")]
        public int THEFTRETENTION { get; set; }

        [XmlElement(ElementName = "INS_MSP_BASE_PREMIUM")]
        public double INSMSPBASEPREMIUM { get; set; }

        [XmlElement(ElementName = "OUT_MSP_BASE_PREMIUM")]
        public double OUTMSPBASEPREMIUM { get; set; }

        [XmlElement(ElementName = "COMP_FRAUD_BASE_PREMIUM")]
        public double COMPFRAUDBASEPREMIUM { get; set; }

        [XmlElement(ElementName = "COMP_FRAUD_FINAL_PREMIUM")]
        public double COMPFRAUDFINALPREMIUM { get; set; }

        [XmlElement(ElementName = "CURR_FRAUD_PREMIUM")]
        public double CURRFRAUDPREMIUM { get; set; }

        [XmlElement(ElementName = "CURR_FRAUD_BASE_PREMIUM")]
        public double CURRFRAUDBASEPREMIUM { get; set; }

        [XmlElement(ElementName = "CURR_FRAUD_FINAL_PREMIUM")]
        public double CURRFRAUDFINALPREMIUM { get; set; }

        [XmlElement(ElementName = "CURR_FRAUD_LD_FACTOR")]
        public double CURRFRAUDLDFACTOR { get; set; }

        [XmlElement(ElementName = "CURR_FRAUD_LIMIT")]
        public double CURRFRAUDLIMIT { get; set; }

        [XmlElement(ElementName = "CURR_FRAUD_RETENTION")]
        public double CURRFRAUDRETENTION { get; set; }

        [XmlElement(ElementName = "FOREIGN_EXPOSURE_MOD")]
        public double FOREIGNEXPOSUREMOD { get; set; }

        [XmlElement(ElementName = "LOSS_ACTIVITY_MOD")]
        public double LOSSACTIVITYMOD { get; set; }

        [XmlElement(ElementName = "PURCHASING_VENDOR_CONTROLS_MOD")]
        public double PURCHASINGVENDORCONTROLSMOD { get; set; }

        [XmlElement(ElementName = "AUDIT_CONTROLS_MOD")]
        public double AUDITCONTROLSMOD { get; set; }

        [XmlElement(ElementName = "BACKGROUND_CHECK_MOD")]
        public double BACKGROUNDCHECKMOD { get; set; }

        [XmlElement(ElementName = "HIGH_VALUE_INVENTORY_MOD")]
        public double HIGHVALUEINVENTORYMOD { get; set; }

        [XmlElement(ElementName = "WORKFORCE")]
        public string WORKFORCE { get; set; }

        [XmlElement(ElementName = "WORKFORCE_MOD")]
        public double WORKFORCEMOD { get; set; }

        [XmlElement(ElementName = "NUM_LOCATIONS_MOD")]
        public double NUMLOCATIONSMOD { get; set; }

        [XmlElement(ElementName = "BANKING")] public string BANKING { get; set; }

        [XmlElement(ElementName = "BANKING_MOD")]
        public double BANKINGMOD { get; set; }

        [XmlElement(ElementName = "VENDOR_MGMNT")]
        public string VENDORMGMNT { get; set; }

        [XmlElement(ElementName = "VENDOR_MGMNT_MOD")]
        public double VENDORMGMNTMOD { get; set; }

        [XmlElement(ElementName = "FIN_STABILITY")]
        public string FINSTABILITY { get; set; }

        [XmlElement(ElementName = "FIN_STABILITY_MOD")]
        public double FINSTABILITYMOD { get; set; }

        [XmlElement(ElementName = "QUAL_MGMNT")]
        public string QUALMGMNT { get; set; }

        [XmlElement(ElementName = "QUAL_MGMNT_MOD")]
        public double QUALMGMNTMOD { get; set; }

        [XmlElement(ElementName = "YEAR_IN_BUS")]
        public double YEARINBUS { get; set; }

        [XmlElement(ElementName = "YEAR_IN_BUS_MOD")]
        public double YEARINBUSMOD { get; set; }

        [XmlElement(ElementName = "MERGER")] public string MERGER { get; set; }

        [XmlElement(ElementName = "MERGER_MOD")]
        public double MERGERMOD { get; set; }

        [XmlElement(ElementName = "COMPLEX_RISK")]
        public string COMPLEXRISK { get; set; }

        [XmlElement(ElementName = "COMPLEX_RISK_MOD")]
        public double COMPLEXRISKMOD { get; set; }

        [XmlElement(ElementName = "INTERNAL_CNTRL")]
        public string INTERNALCNTRL { get; set; }

        [XmlElement(ElementName = "INTERNAL_CNTRL_MOD")]
        public double INTERNALCNTRLMOD { get; set; }

        [XmlElement(ElementName = "UW_INTENSE")]
        public string UWINTENSE { get; set; }

        [XmlElement(ElementName = "UW_INTENSE_MOD")]
        public double UWINTENSEMOD { get; set; }

        [XmlElement(ElementName = "ADD_KR_Q")] public int ADDKRQ { get; set; }

        [XmlElement(ElementName = "ADD_INS_MSP_Q")]
        public int ADDINSMSPQ { get; set; }

        [XmlElement(ElementName = "ADD_OUT_MSP_Q")]
        public int ADDOUTMSPQ { get; set; }

        [XmlElement(ElementName = "ADD_FORGERY_Q")]
        public int ADDFORGERYQ { get; set; }

        [XmlElement(ElementName = "ADD_COMP_FRAUD_Q")]
        public int ADDCOMPFRAUDQ { get; set; }

        [XmlElement(ElementName = "ADD_CURR_FRAUD_Q")]
        public int ADDCURRFRAUDQ { get; set; }

        [XmlElement(ElementName = "ADD_CUST_PROP_Q")]
        public int ADDCUSTPROPQ { get; set; }

        [XmlElement(ElementName = "ADD_INVEST_COST_Q")]
        public int ADDINVESTCOSTQ { get; set; }

        [XmlElement(ElementName = "CUST_PROP_LIMIT")]
        public double CUSTPROPLIMIT { get; set; }

        [XmlElement(ElementName = "CUST_PROP_FACTOR")]
        public double CUSTPROPFACTOR { get; set; }

        [XmlElement(ElementName = "CUST_PROP_RETENTION")]
        public int CUSTPROPRETENTION { get; set; }

        [XmlElement(ElementName = "IN_PREMISES_CLASSES")]
        public string INPREMISESCLASSES { get; set; }

        [XmlElement(ElementName = "OUT_PREMISES_CLASSES")]
        public string OUTPREMISESCLASSES { get; set; }

        [XmlElement(ElementName = "INS_MSP_BASE_RATE_FACTOR")]
        public double INSMSPBASERATEFACTOR { get; set; }

        [XmlElement(ElementName = "OUT_MSP_BASE_RATE_FACTOR")]
        public double OUTMSPBASERATEFACTOR { get; set; }

        [XmlElement(ElementName = "SALES_MODIFIER")]
        public double SALESMODIFIER { get; set; }

        [XmlElement(ElementName = "INTERNET_REVENUES")]
        public double INTERNETREVENUES { get; set; }

        [XmlElement(ElementName = "LOSS_SUSTAINED_COV_EXT_FACTOR")]
        public double LOSSSUSTAINEDCOVEXTFACTOR { get; set; }

        [XmlElement(ElementName = "ADD_PAY_INSTR_FRAUD_Q")]
        public int ADDPAYINSTRFRAUDQ { get; set; }

        [XmlElement(ElementName = "PAY_INSTR_FRAUD_LIMIT")]
        public double PAYINSTRFRAUDLIMIT { get; set; }

        [XmlElement(ElementName = "PAY_INSTR_FRAUD_DED")]
        public double PAYINSTRFRAUDDED { get; set; }

        [XmlElement(ElementName = "PAY_INSTR_FRAUD_RSKPER")]
        public double PAYINSTRFRAUDRSKPER { get; set; }

        [XmlElement(ElementName = "KR_LIMIT")] public double KRLIMIT { get; set; }

        [XmlElement(ElementName = "KR_DEDUCTIBLE")]
        public double KRDEDUCTIBLE { get; set; }

        [XmlElement(ElementName = "KR_BASE_RATE")]
        public double KRBASERATE { get; set; }

        [XmlElement(ElementName = "KR_PREMIUM")]
        public double KRPREMIUM { get; set; }

        [XmlElement(ElementName = "KR_LIMIT_FACTOR")]
        public double KRLIMITFACTOR { get; set; }

        [XmlElement(ElementName = "KR_DED_FACTOR")]
        public double KRDEDFACTOR { get; set; }

        [XmlElement(ElementName = "KR_FOREIGN_TRAVEL")]
        public string KRFOREIGNTRAVEL { get; set; }

        [XmlElement(ElementName = "KR_FOREIGN_TRAVEL_MOD")]
        public double KRFOREIGNTRAVELMOD { get; set; }

        [XmlElement(ElementName = "KR_FOREIGN_LOC")]
        public string KRFOREIGNLOC { get; set; }

        [XmlElement(ElementName = "KR_FOREIGN_LOC_MOD")]
        public double KRFOREIGNLOCMOD { get; set; }

        [XmlElement(ElementName = "KR_CLS_OF_BUS")]
        public string KRCLSOFBUS { get; set; }

        [XmlElement(ElementName = "KR_CLS_OF_BUS_MOD")]
        public double KRCLSOFBUSMOD { get; set; }

        [XmlElement(ElementName = "KR_PRIOR_CLAIMS")]
        public string KRPRIORCLAIMS { get; set; }

        [XmlElement(ElementName = "KR_PRIOR_CLAIMS_MOD")]
        public double KRPRIORCLAIMSMOD { get; set; }

        [XmlElement(ElementName = "KR_FIN_STABILITY")]
        public string KRFINSTABILITY { get; set; }

        [XmlElement(ElementName = "KR_FIN_STABILITY_MOD")]
        public double KRFINSTABILITYMOD { get; set; }

        [XmlElement(ElementName = "KR_QUAL_MGMNT")]
        public string KRQUALMGMNT { get; set; }

        [XmlElement(ElementName = "KR_QUAL_MGMNT_MOD")]
        public double KRQUALMGMNTMOD { get; set; }

        [XmlElement(ElementName = "KR_CO_EXPOSURE")]
        public string KRCOEXPOSURE { get; set; }

        [XmlElement(ElementName = "KR_CO_EXPOSURE_MOD")]
        public double KRCOEXPOSUREMOD { get; set; }

        [XmlElement(ElementName = "ADD_KR_REP_COSTS_Q")]
        public int ADDKRREPCOSTSQ { get; set; }

        [XmlElement(ElementName = "ADD_KR_RECALL_COSTS_Q")]
        public int ADDKRRECALLCOSTSQ { get; set; }

        [XmlElement(ElementName = "KR_REP_COSTS_REGION")]
        public string KRREPCOSTSREGION { get; set; }

        [XmlElement(ElementName = "KR_REP_COSTS_FACTOR")]
        public double KRREPCOSTSFACTOR { get; set; }

        [XmlElement(ElementName = "KR_RECALL_COSTS_REASON")]
        public string KRRECALLCOSTSREASON { get; set; }

        [XmlElement(ElementName = "KR_RECALL_COSTS_FACTOR")]
        public double KRRECALLCOSTSFACTOR { get; set; }

        [XmlElement(ElementName = "KR_CUSTODY_LIMIT")]
        public double KRCUSTODYLIMIT { get; set; }

        [XmlElement(ElementName = "KR_CUSTODY_DED")]
        public double KRCUSTODYDED { get; set; }

        [XmlElement(ElementName = "KR_CLAIM_COST_LIMIT")]
        public double KRCLAIMCOSTLIMIT { get; set; }

        [XmlElement(ElementName = "KR_CLAIM_COST_DED")]
        public double KRCLAIMCOSTDED { get; set; }

        [XmlElement(ElementName = "KR_RESPONSE_COST_LIMIT")]
        public double KRRESPONSECOSTLIMIT { get; set; }

        [XmlElement(ElementName = "KR_RESPONSE_COST_DED")]
        public double KRRESPONSECOSTDED { get; set; }

        [XmlElement(ElementName = "KR_PERS_INJ_LIMIT")]
        public double KRPERSINJLIMIT { get; set; }

        [XmlElement(ElementName = "KR_PERS_INJ_DED")]
        public double KRPERSINJDED { get; set; }

        [XmlElement(ElementName = "KR_REP_COSTS_LIMIT")]
        public double KRREPCOSTSLIMIT { get; set; }

        [XmlElement(ElementName = "KR_REP_COSTS_DED")]
        public double KRREPCOSTSDED { get; set; }

        [XmlElement(ElementName = "KR_RECALL_COSTS_LIMIT")]
        public double KRRECALLCOSTSLIMIT { get; set; }

        [XmlElement(ElementName = "KR_RECALL_COSTS_DED")]
        public double KRRECALLCOSTSDED { get; set; }

        [XmlElement(ElementName = "FORGERY_BASE_PREMIUM")]
        public double FORGERYBASEPREMIUM { get; set; }

        [XmlElement(ElementName = "TOTAL_MOD")]
        public double TOTALMOD { get; set; }

        [XmlElement(ElementName = "LOSS_SUSTAIN_DISC")]
        public int LOSSSUSTAINDISC { get; set; }

        [XmlElement(ElementName = "LOSS_SUSTAIN_DISC_FACTOR")]
        public double LOSSSUSTAINDISCFACTOR { get; set; }

        [XmlElement(ElementName = "FINAL_FORGERY_COV_PART_PREMIUM_PR")]
        public double FINALFORGERYCOVPARTPREMIUMPR { get; set; }

        [XmlElement(ElementName = "FINAL_INS_MSP_COV_PART_PREMIUM_PR")]
        public double FINALINSMSPCOVPARTPREMIUMPR { get; set; }

        [XmlElement(ElementName = "FINAL_OUT_MSP_COV_PART_PREMIUM_PR")]
        public double FINALOUTMSPCOVPARTPREMIUMPR { get; set; }

        [XmlElement(ElementName = "FINAL_THEFT_COV_ART_PREMIUM_PR")]
        public double FINALTHEFTCOVARTPREMIUMPR { get; set; }

        [XmlElement(ElementName = "COMP_FRAUD_FINAL_PREMIUM_PR")]
        public double COMPFRAUDFINALPREMIUMPR { get; set; }

        [XmlElement(ElementName = "CURR_FRAUD_FINAL_PREMIUM_PR")]
        public double CURRFRAUDFINALPREMIUMPR { get; set; }

        [XmlElement(ElementName = "KR_PREMIUM_PR")]
        public double KRPREMIUMPR { get; set; }

        [XmlElement(ElementName = "PREMIUM_PR")]
        public double PREMIUMPR { get; set; }

        [XmlElement(ElementName = "OVERRIDE_THEFT_PREM")]
        public int OVERRIDETHEFTPREM { get; set; }

        [XmlElement(ElementName = "OVERRIDE_IN_PREMISES_PREM")]
        public int OVERRIDEINPREMISESPREM { get; set; }

        [XmlElement(ElementName = "OVERRIDE_OUT_PREMISES_PREM")]
        public int OVERRIDEOUTPREMISESPREM { get; set; }

        [XmlElement(ElementName = "OVERRIDE_COMP_FRAUD_PREM")]
        public int OVERRIDECOMPFRAUDPREM { get; set; }

        [XmlElement(ElementName = "OVERRIDE_CURR_FRAUD_PREM")]
        public int OVERRIDECURRFRAUDPREM { get; set; }

        [XmlElement(ElementName = "OVERRIDE_FORGERY_PREM")]
        public int OVERRIDEFORGERYPREM { get; set; }

        [XmlElement(ElementName = "OVERRIDE_KR_PREM")]
        public int OVERRIDEKRPREM { get; set; }

        [XmlElement(ElementName = "INVEST_COST_FACTOR")]
        public double INVESTCOSTFACTOR { get; set; }

        [XmlElement(ElementName = "IN_PREMISES_TOTAL_MOD")]
        public double INPREMISESTOTALMOD { get; set; }

        [XmlElement(ElementName = "OUT_PREMISES_TOTAL_MOD")]
        public double OUTPREMISESTOTALMOD { get; set; }

        [XmlElement(ElementName = "FORGERY_TOTAL_MOD")]
        public double FORGERYTOTALMOD { get; set; }

        [XmlElement(ElementName = "COMP_FRAUD_TOTAL_MOD")]
        public double COMPFRAUDTOTALMOD { get; set; }

        [XmlElement(ElementName = "CURR_FRAUD_TOTAL_MOD")]
        public double CURRFRAUDTOTALMOD { get; set; }

        [XmlElement(ElementName = "KR_TOTAL_MOD")]
        public double KRTOTALMOD { get; set; }

        [XmlElement(ElementName = "INPREM_DED_FACTOR")]
        public double INPREMDEDFACTOR { get; set; }

        [XmlElement(ElementName = "OUTPREM_DED_FACTOR")]
        public double OUTPREMDEDFACTOR { get; set; }

        [XmlElement(ElementName = "COMP_FRAUD_DED_FACTOR")]
        public double COMPFRAUDDEDFACTOR { get; set; }

        [XmlElement(ElementName = "INPREM_LIMIT_FACTOR")]
        public double INPREMLIMITFACTOR { get; set; }

        [XmlElement(ElementName = "OUTPREM_LIMIT_FACTOR")]
        public double OUTPREMLIMITFACTOR { get; set; }

        [XmlElement(ElementName = "COMP_FRAUD_LIMIT_FACTOR")]
        public double COMPFRAUDLIMITFACTOR { get; set; }

        [XmlElement(ElementName = "THEFT_STATE_SCHEDULE_MOD")]
        public double THEFTSTATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "INPREM_STATE_SCHEDULE_MOD")]
        public double INPREMSTATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "OUTPREM_STATE_SCHEDULE_MOD")]
        public double OUTPREMSTATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "FORGERY_STATE_SCHEDULE_MOD")]
        public double FORGERYSTATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "CURRFRAUD_STATE_SCHEDULE_MOD")]
        public double CURRFRAUDSTATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "COMPFRAUD_STATE_SCHEDULE_MOD")]
        public double COMPFRAUDSTATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "KR_STATE_SCHEDULE_MOD")]
        public double KRSTATESCHEDULEMOD { get; set; }

        [XmlElement(ElementName = "THEFT_LIMIT_FACTOR")]
        public double THEFTLIMITFACTOR { get; set; }

        [XmlElement(ElementName = "THEFT_RETENTION_FACTOR")]
        public double THEFTRETENTIONFACTOR { get; set; }
    }

    [XmlRoot(ElementName = "POLICY_AFF_DNO")]
    public class POLICYAFFDNO
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "KEYF")] public int KEYF { get; set; }

        [XmlElement(ElementName = "ADD_CRIME_Q")]
        public int ADDCRIMEQ { get; set; }

        [XmlElement(ElementName = "ADD_FID_Q")]
        public int ADDFIDQ { get; set; }

        [XmlElement(ElementName = "ALREADY_PURCHASED")]
        public int ALREADYPURCHASED { get; set; }

        [XmlElement(ElementName = "AUD_IVST_COMP_COMM_Q")]
        public string AUDIVSTCOMPCOMMQ { get; set; }

        [XmlElement(ElementName = "CRIME_COV_PREMIUM")]
        public int CRIMECOVPREMIUM { get; set; }

        [XmlElement(ElementName = "DATE_OF_INCORPORATION")]
        public DateTime DATEOFINCORPORATION { get; set; }

        [XmlElement(ElementName = "DEFENSE_OUTSIDE_LIMITS")]
        public int DEFENSEOUTSIDELIMITS { get; set; }

        [XmlElement(ElementName = "INSURANCE_PRODUCTS_Q")]
        public int INSURANCEPRODUCTSQ { get; set; }

        [XmlElement(ElementName = "LABOR_NEGOTIATIONS_Q")]
        public int LABORNEGOTIATIONSQ { get; set; }

        [XmlElement(ElementName = "NEG_FUND_BAL_Q")]
        public int NEGFUNDBALQ { get; set; }

        [XmlElement(ElementName = "NON_EPL_DEDUCTIBLE")]
        public int NONEPLDEDUCTIBLE { get; set; }

        [XmlElement(ElementName = "NUM_FT_EMPLOYEES")]
        public int NUMFTEMPLOYEES { get; set; }

        [XmlElement(ElementName = "NUM_PT_EMPLOYEES")]
        public int NUMPTEMPLOYEES { get; set; }

        [XmlElement(ElementName = "NUM_TERM_EMPLOYEES")]
        public int NUMTERMEMPLOYEES { get; set; }

        [XmlElement(ElementName = "NUM_VOLUNTEERS")]
        public int NUMVOLUNTEERS { get; set; }

        [XmlElement(ElementName = "OPTION_NUMBER")]
        public int OPTIONNUMBER { get; set; }

        [XmlElement(ElementName = "PRIMARY_OPTION")]
        public int PRIMARYOPTION { get; set; }

        [XmlElement(ElementName = "REVENUES")] public int REVENUES { get; set; }

        [XmlElement(ElementName = "SEPARATE_LIMITS_PREMIUM")]
        public int SEPARATELIMITSPREMIUM { get; set; }

        [XmlElement(ElementName = "SHORT_TERM")]
        public int SHORTTERM { get; set; }

        [XmlElement(ElementName = "SUB_CLASS")]
        public string SUBCLASS { get; set; }

        [XmlElement(ElementName = "TOTAL_PREMIUM")]
        public int TOTALPREMIUM { get; set; }

        [XmlElement(ElementName = "YEAR_COLLECTED")]
        public int YEARCOLLECTED { get; set; }

        [XmlElement(ElementName = "ASSETS")] public double ASSETS { get; set; }

        [XmlElement(ElementName = "NUM_LOCATIONS")]
        public string NUMLOCATIONS { get; set; }

        [XmlElement(ElementName = "ADD_ERP_Q")]
        public int ADDERPQ { get; set; }

        [XmlElement(ElementName = "ERP_CHARGE")]
        public double ERPCHARGE { get; set; }

        [XmlElement(ElementName = "ADD_CLAIM_SETTLE_Q")]
        public int ADDCLAIMSETTLEQ { get; set; }

        [XmlElement(ElementName = "CLAIM_SETTLE_CHARGE")]
        public double CLAIMSETTLECHARGE { get; set; }

        [XmlElement(ElementName = "ADD_DEFENSE_OUTSIDE_Q")]
        public int ADDDEFENSEOUTSIDEQ { get; set; }

        [XmlElement(ElementName = "ADD_DFNS_OUT_SHARED_Q")]
        public int ADDDFNSOUTSHAREDQ { get; set; }

        [XmlElement(ElementName = "DFNS_OUT_SHARED_CHARGE")]
        public double DFNSOUTSHAREDCHARGE { get; set; }

        [XmlElement(ElementName = "ADD_WAGE_HR_Q")]
        public int ADDWAGEHRQ { get; set; }

        [XmlElement(ElementName = "ADD_EXS_BEN_TAX_Q")]
        public int ADDEXSBENTAXQ { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_Q")]
        public int EXCESSDOQ { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_LIMIT")]
        public double EXCESSDOLIMIT { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_PRIM_LIMIT_1")]
        public double EXCESSDOPRIMLIMIT1 { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_PRIM_PREM_1")]
        public double EXCESSDOPRIMPREM1 { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_PERCENT")]
        public double EXCESSDOPERCENT { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_ADEQUATE_Q")]
        public int EXCESSDOADEQUATEQ { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_BF_Q")]
        public int EXCESSDOBFQ { get; set; }

        [XmlElement(ElementName = "WAGE_HR_LIMIT")]
        public double WAGEHRLIMIT { get; set; }

        [XmlElement(ElementName = "EXS_BEN_LIMIT")]
        public double EXSBENLIMIT { get; set; }

        [XmlElement(ElementName = "INFLATION_PERCENT")]
        public double INFLATIONPERCENT { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_PRIM_DEDUCTIBLE_1")]
        public double EXCESSDOPRIMDEDUCTIBLE1 { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_PRIM_DEDUCTIBLE_2")]
        public double EXCESSDOPRIMDEDUCTIBLE2 { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_PRIM_LIMIT_2")]
        public double EXCESSDOPRIMLIMIT2 { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_PRIM_PREM_2")]
        public double EXCESSDOPRIMPREM2 { get; set; }

        [XmlElement(ElementName = "DEFENSE_OUTSIDE_CHARGE")]
        public double DEFENSEOUTSIDECHARGE { get; set; }

        [XmlElement(ElementName = "UW_NOTES")] public string UWNOTES { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_ATTACH_POINT")]
        public double EXCESSDOATTACHPOINT { get; set; }

        [XmlElement(ElementName = "EXCESS_DO_RATE_PER_MIL")]
        public double EXCESSDORATEPERMIL { get; set; }

        [XmlElement(ElementName = "MERGER_ACQUISITION")]
        public string MERGERACQUISITION { get; set; }

        [XmlElement(ElementName = "CLASS_CODE")]
        public string CLASSCODE { get; set; }

        [XmlElement(ElementName = "SEPARATE_CYBER_POL_SOLD")]
        public int SEPARATECYBERPOLSOLD { get; set; }

        [XmlElement(ElementName = "POLICY_AFF_DNO_DOEPL")]
        public POLICYAFFDNODOEPL POLICYAFFDNODOEPL { get; set; }

        [XmlElement(ElementName = "POLICY_AFF_DNO_FID")]
        public POLICYAFFDNOFID POLICYAFFDNOFID { get; set; }

        [XmlElement(ElementName = "POLICY_AFF_DNO_CRIME")]
        public POLICYAFFDNOCRIME POLICYAFFDNOCRIME { get; set; }
    }

    [XmlRoot(ElementName = "POLICY_SECTION_COVERAGE")]
    public class POLICYSECTIONCOVERAGE
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "EFFECTIVE_DATE")]
        public DateTime EFFECTIVEDATE { get; set; }

        [XmlElement(ElementName = "EXPIRATION_DATE")]
        public DateTime EXPIRATIONDATE { get; set; }

        [XmlElement(ElementName = "LIMIT")] public double LIMIT { get; set; }

        [XmlElement(ElementName = "PREMIUM")] public double PREMIUM { get; set; }

        [XmlElement(ElementName = "PROGRAM_COVERAGE")]
        public int PROGRAMCOVERAGE { get; set; }

        [XmlElement(ElementName = "PROGRAM_SECTION")]
        public int PROGRAMSECTION { get; set; }
    }

    [XmlRoot(ElementName = "POLICY_COVERAGE")]
    public class POLICYCOVERAGE
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "ANNUAL_CHANGE_PREMIUM")]
        public double ANNUALCHANGEPREMIUM { get; set; }

        [XmlElement(ElementName = "DEDUCTIBLE")]
        public int DEDUCTIBLE { get; set; }

        [XmlElement(ElementName = "EFFECTIVE_DATE")]
        public DateTime EFFECTIVEDATE { get; set; }

        [XmlElement(ElementName = "EXPIRATION_DATE")]
        public DateTime EXPIRATIONDATE { get; set; }

        [XmlElement(ElementName = "LIMIT")] public int LIMIT { get; set; }

        [XmlElement(ElementName = "NEW_ANNUAL_PREMIUM")]
        public double NEWANNUALPREMIUM { get; set; }

        [XmlElement(ElementName = "NEW_TERM_PREMIUM")]
        public double NEWTERMPREMIUM { get; set; }

        [XmlElement(ElementName = "PREMIUM")] public double PREMIUM { get; set; }

        [XmlElement(ElementName = "PREV_ANNUAL_PREMIUM")]
        public double PREVANNUALPREMIUM { get; set; }

        [XmlElement(ElementName = "PREV_EFFECTIVE_DATE")]
        public DateTime PREVEFFECTIVEDATE { get; set; }

        [XmlElement(ElementName = "PREV_EXPIRATION_DATE")]
        public DateTime PREVEXPIRATIONDATE { get; set; }

        [XmlElement(ElementName = "PREV_TERM_PREMIUM")]
        public double PREVTERMPREMIUM { get; set; }

        [XmlElement(ElementName = "PROGRAM_COVERAGE")]
        public int PROGRAMCOVERAGE { get; set; }

        [XmlElement(ElementName = "PRORATA")] public int PRORATA { get; set; }

        [XmlElement(ElementName = "PRORATA_PREMIUM")]
        public double PRORATAPREMIUM { get; set; }

        [XmlElement(ElementName = "RECALCULATE")]
        public int RECALCULATE { get; set; }

        [XmlElement(ElementName = "TERM_CHANGE_PREMIUM")]
        public double TERMCHANGEPREMIUM { get; set; }

        [XmlElement(ElementName = "TERM_FACTOR")]
        public int TERMFACTOR { get; set; }

        [XmlElement(ElementName = "OVERRIDE_PREMIUM")]
        public int OVERRIDEPREMIUM { get; set; }

        [XmlElement(ElementName = "POLICY_SECTION_COVERAGE")]
        public POLICYSECTIONCOVERAGE POLICYSECTIONCOVERAGE { get; set; }
    }

    [XmlRoot(ElementName = "POLICY_SECTION")]
    public class POLICYSECTION
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "COVERAGE_PREMIUM")]
        public double COVERAGEPREMIUM { get; set; }

        [XmlElement(ElementName = "EFFECTIVE_DATE")]
        public DateTime EFFECTIVEDATE { get; set; }

        [XmlElement(ElementName = "EXPIRATION_DATE")]
        public DateTime EXPIRATIONDATE { get; set; }

        [XmlElement(ElementName = "FILING_COUNTRY")]
        public string FILINGCOUNTRY { get; set; }

        [XmlElement(ElementName = "MIN_EARNED_ADJUSTMENT")]
        public double MINEARNEDADJUSTMENT { get; set; }

        [XmlElement(ElementName = "PREMIUM")] public double PREMIUM { get; set; }

        [XmlElement(ElementName = "PROGRAM_SECTION")]
        public int PROGRAMSECTION { get; set; }

        [XmlElement(ElementName = "WAIVE_PREMIUM")]
        public double WAIVEPREMIUM { get; set; }
    }

    [XmlRoot(ElementName = "POLICY_LOCATION")]
    public class POLICYLOCATION
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "CITY")] public string CITY { get; set; }

        [XmlElement(ElementName = "COUNTRY")] public string COUNTRY { get; set; }

        [XmlElement(ElementName = "INSIDE_CITY_LIMITS")]
        public int INSIDECITYLIMITS { get; set; }

        [XmlElement(ElementName = "LOCATION_INDEX")]
        public int LOCATIONINDEX { get; set; }

        [XmlElement(ElementName = "PRIMARY_LOCATION")]
        public int PRIMARYLOCATION { get; set; }

        [XmlElement(ElementName = "STATE")] public string STATE { get; set; }

        [XmlElement(ElementName = "STREET")] public string STREET { get; set; }

        [XmlElement(ElementName = "STREET_LINE1")]
        public string STREETLINE1 { get; set; }

        [XmlElement(ElementName = "ZIP_CODE")] public int ZIPCODE { get; set; }
    }

    [XmlRoot(ElementName = "PROGRAM_SECTION")]
    public class PROGRAMSECTION
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "SECTION_NAME")]
        public string SECTIONNAME { get; set; }

        [XmlElement(ElementName = "DESCRIPTION")]
        public string DESCRIPTION { get; set; }
    }

    [XmlRoot(ElementName = "PROGRAM_SECTION_TABLE")]
    public class PROGRAMSECTIONTABLE
    {

        [XmlElement(ElementName = "PROGRAM_SECTION")]
        public List<PROGRAMSECTION> PROGRAMSECTION { get; set; }
    }

    [XmlRoot(ElementName = "PROGRAM_COVERAGE")]
    public class PROGRAMCOVERAGE
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "COVERAGE_NAME")]
        public string COVERAGENAME { get; set; }

        [XmlElement(ElementName = "DESCRIPTION")]
        public string DESCRIPTION { get; set; }

        [XmlElement(ElementName = "SORT_ORDER")]
        public int SORTORDER { get; set; }
    }

    [XmlRoot(ElementName = "PROGRAM_COVERAGE_TABLE")]
    public class PROGRAMCOVERAGETABLE
    {

        [XmlElement(ElementName = "PROGRAM_COVERAGE")]
        public List<PROGRAMCOVERAGE> PROGRAMCOVERAGE { get; set; }
    }

    [XmlRoot(ElementName = "PROGRAM_POLICY_TYPE")]
    public class PROGRAMPOLICYTYPE
    {

        [XmlElement(ElementName = "KEY")] public int KEY { get; set; }

        [XmlElement(ElementName = "POLICY_TYPE_NAME")]
        public string POLICYTYPENAME { get; set; }

        [XmlElement(ElementName = "DESCRIPTION")]
        public string DESCRIPTION { get; set; }

        [XmlElement(ElementName = "ALLOW_TO_SETUP_FACILITY")]
        public int ALLOWTOSETUPFACILITY { get; set; }
    }

    [XmlRoot(ElementName = "PROGRAM_POLICY_TYPE_TABLE")]
    public class PROGRAMPOLICYTYPETABLE
    {

        [XmlElement(ElementName = "PROGRAM_POLICY_TYPE")]
        public List<PROGRAMPOLICYTYPE> PROGRAMPOLICYTYPE { get; set; }
    }
}