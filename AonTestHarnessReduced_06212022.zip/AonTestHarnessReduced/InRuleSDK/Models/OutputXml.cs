﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKRunner573.Models
{
    public class OutputXmlClass
    {
        public string OutputXml { get; set; }
        public string OutputXmlFileName { get; set; }
    }
}
