﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKRunner573.Models
{
    public interface IAppSettings
    {

    }
    public class AppSettings
    {
        [Required]
        public string LogFilePath { get; set; }
        [Required]
        public List<string> EntityNames { get; set; }
        [Required]
        public string XmlFilePath { get; set; }
        [Required]
        public string RuleAppPath { get; set; }

        public string SaveFilePath { get; set; }
        [Required]
        public List<string> RuleSets { get; set; }
        [Required]
        public List<string> RuleAppNames { get; set; }
        [Required]
        public List<string> FileDates { get; set; }
    }
    public class RuleSets
    {
        public List<string> Rating { get; set; }
        public List<string> Forms { get; set; }
    }
    public class EntityNames
    {
        public List<string> Rating { get; set; }
        public List<string> Forms { get; set; }
    }
}
