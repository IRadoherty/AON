﻿using System.Runtime.CompilerServices;
using ChoETL;
using InRule.Authoring.BusinessLanguage;
using InRule.Authoring.Reporting;
using InRule.Runtime;
using SDKRunner573.Models;
using Serilog;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.XPath;
using InRule.Repository;
using InRule.Repository.RuleElements;
using XmlDiffLib;

namespace SDKRunner573;
/// <summary>
/// Runs XML files against 5.7.3 SDK based on entries defined in the appsettings.json file.
/// </summary>
public interface IRunSdk
{
    void Start();
}

public class RunSdk573 : IRunSdk
{
    private static readonly AppSettings AppSettings = Program._appSettings;

    private RuleSession m_session = null;
    private Entity m_entity = null;
    private XPathEntityModel m_model = new();
    
    public void Start()
    {
        // Input file format: RuleAppName FileDate
        // Output file format: RuleAppName FileDate RuleSet ( OutputV2 or v573_Output is generated )
        const bool runSdk = false;
        const bool compareInputFiles = false; // Run rules against valid XML files
        // Compare output files
        ValidateXmlFiles();
        TestAonCode();


        if (runSdk)
        {
            // Validate XML files
            ValidateXmlFiles();
            const bool runRules = true; // Run rules against valid XML files
            const bool compareFiles = true; // Compare output files
            const bool saveState = false; // Save state
            const bool loadSate = false; // Load state
            const bool pullRuleSets = false; // pull rule sets from rule application
            FilePoller(runRules, compareFiles, saveState, loadSate, pullRuleSets, "Outputv2");
        }

        if (compareInputFiles)
        {
            CompareNamedXmlFiles(
                @"C:\Code\VersionComparison\SDK5.7.3\XMLFiles\D&O Fully Loaded Forms Test 02182022 Input_v5.xml",
                @"C:\Code\VersionComparison\SDK5.7.3\XMLFiles\D&O Fully Loaded Forms POLICY 02182022 Input_Validated.xml",
                @"C:\Code\VersionComparison\SDK5.7.3\XMLFiles\02182022_Input_Compare");
        }
    }

    #region FilePoller

    public void FilePoller(bool runRules, bool compareFiles, bool saveState, bool loadSate, bool pullRuleSets,
        string outputName)
    {
        var directories = GetFiles(true, true);
        var ruleAppFiles = directories.RuleApps;
        var xmlFiles = directories.XmlFiles;
        var ruleAppNames = AppSettings.RuleAppNames;
        var ruleSets = AppSettings.RuleSets;
        var fileDates = AppSettings.FileDates;
        foreach (var ruleApp in ruleAppFiles.Where(ruleApp => ruleApp.FullName.Contains("ruleappx")))
        {
            if (ruleApp is null)
            {
                Log.Logger.Information("No rule app is loaded that matches the set configuration");
                return;
            }

            if (xmlFiles is null)
            {
                Log.Logger.Information("No XML files found to run rules against");
                return;
            }

            foreach (var ruleAppName in ruleAppNames)
            {
                foreach (var fileDate in fileDates)
                {
                    foreach (var xmlFile in xmlFiles.Where(xmlFile =>
                                 xmlFile.Name.Contains("Validated") &&
                                 xmlFile.Name.Contains(ruleAppName) //&& xmlFile.Name.Contains(ruleSet) 
                                 && xmlFile.Name.Contains(fileDate)))
                    {
                        foreach (var ruleSet in ruleSets)
                        {
                            Log.Logger.Information("");
                            Log.Logger.Information("Running 5.7.3 SDK with the following parameters:");
                            Log.Logger.Information("RuleSet: {ruleSet}", ruleSet);
                            Log.Logger.Information("InputXmlFile: {inputXmlFile}", xmlFile.FullName);
                            Log.Logger.Information("RuleAppFile: {ruleAppFile}", ruleApp.FullName);
                            if (runRules)
                            {
                                var outputFile = new OutputXmlClass() { OutputXml = "" };
                                outputFile = RunRulesSdk573(ruleSet, xmlFile.FullName, ruleApp.FullName);
                                if (compareFiles && outputFile.OutputXml != "")
                                    CompareOutputFiles(ruleSet, outputFile, ruleAppName, fileDate, outputName);
                            }

                            if (saveState)
                                SaveStateSDK573(ruleSet, xmlFile.FullName, ruleApp.FullName);
                            if (loadSate)
                                LoadStateSDK573(ruleSet, xmlFile.FullName, ruleApp.FullName);
                            if (pullRuleSets)
                                LoadStateSDK573(ruleSet, xmlFile.FullName, ruleApp.FullName);
                            if (pullRuleSets)
                                PullRuleSets();
                        }
                    }
                }
            }
        }
    }

    #endregion

    #region ValidateXmlFiles

    public void ValidateXmlFiles()
    {
        var directories = GetFiles(false, true);
        var xmlFiles = directories.XmlFiles;
        if (xmlFiles is not null)
        {

            Parallel.ForEach(xmlFiles.Where(xmlFile =>
                xmlFile.Name.Contains("Input") && !xmlFile.Name.Contains("Output")
                                               && !xmlFile.Name.Contains("Results") &&
                                               !xmlFile.Name.Contains("Input_Validated")), xmlFile =>
            {
                Log.Logger.Information("Found input file named: {FullName} was written", xmlFile.FullName);
                var xmlDoc = new XmlDocument();
                xmlDoc.Load(xmlFile.FullName);
                var dataNodes = xmlDoc.SelectNodes($"//POLICY");
                dataNodes = ReplaceXml(dataNodes);
                var outputFile = xmlFile.FullName.Replace(".xml", "").Replace("Input", "Input_Validated") + ".xml";
                if (File.Exists(outputFile)) File.Delete(outputFile);
                File.WriteAllText(outputFile, dataNodes[0].OuterXml);

                Log.Logger.Information("Validation file named {outputFile} was written", outputFile);
            });
        }
        else
        {
            Log.Logger.Information("No XML files found to validate");
        }
    }

    private static XmlNodeList ReplaceXml(XmlNodeList xmlNodeList)
    {
        foreach (XmlNode node in xmlNodeList)
        {
            if (node.HasChildNodes)
                ReplaceXml(node.ChildNodes);
            else
            {
                // get values after a decimal
                if (node.InnerText.Contains("."))
                {
                    var substring = node.InnerText[(node.InnerText.LastIndexOf(".") + 1)..];
                    var substringZ = "." + substring;
                    var isAllZeros = substring
                        .Where(char.IsDigit)
                        .All(x => x == '0');
                    if (!isAllZeros) continue;
                    node.InnerText = node.InnerText.Replace(substringZ, "");
                }
                else
                {
                    node.InnerText = UpdateDate(node.InnerText);
                }
            }
        }

        return xmlNodeList;
    }

    public static string UpdateDate(string date)
    {
        if (DateTime.TryParse(date, out var timeFound))
        {
            date = timeFound.ToString("yyyy-MM-dd");
        }

        return date;
    }

    #endregion

    #region RunSdk573

    public OutputXmlClass RunRulesSdk573(string ruleSet, string inputXmlFile, string ruleAppFile)
    {
        var inputFileName = inputXmlFile[(inputXmlFile.LastIndexOf('/') + 1)..].Replace(".xml", "").Replace("Input", "")
            .Replace("_Validated", "");
        var outputFile = inputFileName + ruleSet + "_v573_Output.xml";
        var ruleAppRef = new FileSystemRuleApplicationReference(ruleAppFile);
        var outputXml = new OutputXmlClass();
        try
        {
            using var session = new RuleSession(ruleAppRef);
            var xmlDoc = new XmlDocument();
            xmlDoc.Load(inputXmlFile);
            var innerXml = xmlDoc.InnerXml;
            var entity = session.CreateEntity("POLICY", innerXml, EntityStateType.Xml);
            switch (ruleSet)
            {
                case "AutoRuleSet":
                    session.ApplyRules();
                    break;
                default:
                    entity.ExecuteRuleSet(ruleSet);
                    break;
            }

            outputXml.OutputXml = entity.GetXml();
            outputXml.OutputXmlFileName = outputFile;

            if (File.Exists(outputXml.OutputXmlFileName))
                File.Delete(outputXml.OutputXmlFileName);
            File.WriteAllText(outputXml.OutputXmlFileName, outputXml.OutputXml);
            Log.Logger.Information("Executed rules and created output file named {outputFile}", outputFile);
        }
        catch (Exception ex)
        {
            Log.Logger.Information(
                $"ERROR with ruleSet:{ruleSet} inputXmlFile:{inputXmlFile} ruleAppFile: {ruleAppFile}: {ex.Message}");
            inputFileName = inputXmlFile.Replace(".xml", "").Replace("Input", "");
            var errorFile = inputFileName + " " + ruleSet + "_ErrorFile.txt";
            if (File.Exists(errorFile))
                File.Delete(errorFile);
            File.WriteAllText(errorFile, ex.Message);
        }

        return outputXml;
    }

    #endregion

    #region RunSdk573byXPath

    public OutputXmlClass RunRulesSdk573ByXPath(string ruleSet, string inputXmlFile, string ruleAppFile)
    {
        var inputFileName = inputXmlFile[(inputXmlFile.LastIndexOf('/') + 1)..].Replace(".xml", "").Replace("Input", "")
            .Replace("_Validated", "");
        var outputFile = inputFileName + ruleSet + "_v573_Output.xml";
        var ruleAppRef = new FileSystemRuleApplicationReference(ruleAppFile);
        var outputXml = new OutputXmlClass();
        try
        {
            using var session = new RuleSession(ruleAppRef);
            var xmlDoc = new XmlDocument();
            xmlDoc.Load(inputXmlFile);
            var innerXml = xmlDoc.InnerXml;
            var entity = session.CreateEntity("POLICY", innerXml, EntityStateType.Xml);
            switch (ruleSet)
            {
                case "AutoRuleSet":
                    session.ApplyRules();
                    break;
                default:
                    entity.ExecuteRuleSet(ruleSet);
                    break;
            }

            outputXml.OutputXml = entity.GetXml();
            outputXml.OutputXmlFileName = outputFile;

            if (File.Exists(outputXml.OutputXmlFileName))
                File.Delete(outputXml.OutputXmlFileName);
            File.WriteAllText(outputXml.OutputXmlFileName, outputXml.OutputXml);
            Log.Logger.Information("Executed rules and created output file named {outputFile}", outputFile);
        }
        catch (Exception ex)
        {
            Log.Logger.Information(
                $"ERROR with ruleSet:{ruleSet} inputXmlFile:{inputXmlFile} ruleAppFile: {ruleAppFile}: {ex.Message}");
            inputFileName = inputXmlFile.Replace(".xml", "").Replace("Input", "");
            var errorFile = inputFileName + " " + ruleSet + "_ErrorFile.txt";
            if (File.Exists(errorFile))
                File.Delete(errorFile);
            File.WriteAllText(errorFile, ex.Message);
        }

        return outputXml;
    }

    #endregion

    #region CompareOutputFiles

    public void CompareOutputFiles(string ruleSet, OutputXmlClass outputFile, string ruleAppName, string fileDate,
        string outputName)
    {
        var directories = GetFiles(false, true);
        var xmlFiles = directories.XmlFiles;
        try
        {
            foreach (var x in xmlFiles.Where(x => x.Name.Contains(outputName) &&
                                                  x.Name.Contains(ruleAppName) &&
                                                  x.Name.Contains(fileDate) &&
                                                  x.Name.Contains(ruleSet)))
            {
                var xmlFileName = x.Name;
                var version29file = File.ReadAllText(x.FullName);
                var diff = new XmlDiff(version29file, outputFile.OutputXml);
                diff.CompareDocuments(new XmlDiffOptions()
                {
                    IgnoreAttributeOrder = true,
                    IgnoreChildOrder = true, IgnoreNamespace = true,
                }); // TwoWayMatch = true, 
                var resultFile = outputFile.OutputXmlFileName;
                resultFile = resultFile.Replace("573_Output", "Results");

                if (File.Exists(resultFile)) File.Delete(resultFile);
                File.WriteAllText(resultFile, diff.ToString());
                Log.Logger.Information("Compared {outputFile} to {xName}", outputFile.OutputXmlFileName, x.Name);
                Log.Logger.Information("Created result file named {resultFile}", resultFile);

                var sb = new StringBuilder();
                using (var p = ChoJSONReader.LoadText(diff.ToString()).WithJSONPath("$..DiffNodeList"))
                {
                    using var w = new ChoCSVWriter(sb).WithFirstLineHeader();
                    w.Write(p);
                }

                resultFile = resultFile.Replace(".xml", ".csv");
                Log.Logger.Information("Created result file named {resultFile}", resultFile);
                if (File.Exists(resultFile)) File.Delete(resultFile);
                File.WriteAllText(resultFile, sb.ToString());
            }
        }
        catch (Exception ex)
        {
            Log.Logger.Information($"ERROR comparing XML files: {ex.Message}");
        }
    }

    #endregion

    #region CompareNamedXmlFiles

    public void CompareNamedXmlFiles(string xmlFile1, string xmlFile2, string compareFileName)
    {
        try
        {
            //var directories = GetFiles(false, true);
            //var xmlFiles = directories.XmlFiles;
            //foreach (var x in xmlFiles.Where(x =>
            //             x.Name.Contains(outputName) && x.Name.Contains(ruleAppName) && x.Name.Contains(fileDate) &&
            //             x.Name.Contains(ruleSet) && x.Name.Contains(entityName)))
            //{
            //}
            //foreach (var x in xmlFiles.Where(x =>
            //             x.Name.Contains(outputName) && x.Name.Contains(ruleAppName) && x.Name.Contains(fileDate) &&
            //             x.Name.Contains(ruleSet) && x.Name.Contains(entityName)))
            //{
            //}

            var file1 = File.ReadAllText(xmlFile1);
            var file2 = File.ReadAllText(xmlFile2);
            var diff = new XmlDiff(file1, file2);
            diff.CompareDocuments(new XmlDiffOptions()
                {IgnoreAttributeOrder = true, IgnoreChildOrder = true, IgnoreNamespace = true});

            compareFileName += ".xml";

            if (File.Exists(compareFileName)) File.Delete(compareFileName);
            File.WriteAllText(compareFileName, diff.ToString());
            var sb = new StringBuilder();
            using var p = ChoJSONReader.LoadText(diff.ToString()).WithJSONPath("$..DiffNodeList");
            using var w = new ChoCSVWriter(sb).WithFirstLineHeader();
            w.Write(p);
            compareFileName.Replace("xml", "csv");
            if (File.Exists(compareFileName)) File.Delete(compareFileName);
            File.WriteAllText(compareFileName, sb.ToString());

            Log.Logger.Information("Compared {xmlFile1} to {xmlFile2}", xmlFile1, xmlFile2);
            Log.Logger.Information("Created result file named {compareFileName}", compareFileName);
        }
        catch (Exception ex)
        {
            Log.Logger.Information($"ERROR comparing XML files: {ex.Message}");
        }
    }

    #endregion

    #region SaveStateSDK573

    public void SaveStateSDK573(string ruleSet, string inputXmlFile, string ruleAppFile)
    {
        var ruleAppRef = new FileSystemRuleApplicationReference(ruleAppFile);
        try
        {
            using var session = new RuleSession(ruleAppRef);
            var xmlDoc = new XmlDocument();
            xmlDoc.Load(inputXmlFile);
            var entity = session.CreateEntity("POLICY", xmlDoc.InnerXml, EntityStateType.Xml);
            switch (ruleSet)
            {
                case "AutoRuleSet":
                    session.ApplyRules();
                    break;
                default:
                    entity.ExecuteRuleSet(ruleSet);
                    break;
            }

            var entityNameCheck = entity.Name;
            session.SaveState(@"C:\Code\VersionComparison\SDK5.7.3\Cache\state.testscenario");
            Log.Logger.Information(
                @$"Saved session state with entity {entityNameCheck} to : C:\Code\VersionComparison\SDK5.7.3\Cache\state.testscenario");
        }
        catch (Exception ex)
        {
            Log.Logger.Information($"ERROR: {ex.Message}");
        }
    }

    #endregion

    #region LoadStateSDK573

    public void LoadStateSDK573(string ruleSet, string inputXmlFile, string ruleAppFile)
    {
        try
        {
            var ruleAppRef = new FileSystemRuleApplicationReference(ruleAppFile);
            var xmlDoc = new XmlDocument();
            xmlDoc.Load(inputXmlFile);

            using var session = new RuleSession(ruleAppRef);
            session.LoadState(@"C:\Code\VersionComparison\SDK5.7.3\Cache\state.testscenario");
            var entity = session.CreateEntity("POLICY", xmlDoc.InnerXml, EntityStateType.Xml);
            var entityNameCheck = entity.Name;
            Log.Logger.Information(
                @$"Loaded session state with entity {entityNameCheck} : C:\Code\VersionComparison\SDK5.7.3\Cache\state.testscenario");
        }
        catch (Exception ex)
        {
            Log.Logger.Information($"ERROR loading session state: {ex.Message}");
        }
    }

    #endregion

    #region GetFiles

    public Directories GetFiles(bool ruleApps, bool xmlFiles)
    {
        var directories = new Directories();
        if (ruleApps)
        {
            var ruleAppDirectory = new DirectoryInfo(AppSettings.RuleAppPath);
            directories.RuleApps = ruleAppDirectory.GetFiles("*.ruleappx*");
        }

        if (xmlFiles != true) return directories;
        var xmlFileDirectory = new DirectoryInfo(AppSettings.XmlFilePath);
        directories.XmlFiles = xmlFileDirectory.GetFiles("*.xml*");

        return directories;
    }

    #endregion

    #region PullRuleSets

    public void PullRuleSets()
    {
        var directories = GetFiles(true, false);
        var ruleAppNames = AppSettings.RuleAppNames;
        foreach (var ruleApp in directories.RuleApps)
        {
            foreach (var ruleAppDef in from ruleAppName in ruleAppNames
                     where ruleApp.Name.Contains(ruleAppName)
                     select ruleApp.FullName
                     into ruleAppFile
                     select new FileSystemRuleApplicationReference(ruleAppFile)
                     into ruleAppRef
                     select ruleAppRef.GetRuleApplicationDef())
            {
                Log.Logger.Information("Entity and rules for: {ruleApp}", ruleApp.Name);
                foreach (var entity in ruleAppDef.Entities)
                {
                    var e = (dynamic) entity;
                    var ruleElements = e.RuleElements;
                    foreach (var ruleElement in ruleElements)
                    {
                        var r = (dynamic) ruleElement;
                        var path = r.AuthoringElementPath;
                        Log.Logger.Information("entity.ruleset {path}", path);

                    }
                }
            }
        }
    }

    #endregion

    #region GetRuleAppReport

    public void GetRuleAppReport()
    {
        var directories = GetFiles(true, false);
        var ruleAppNames = AppSettings.RuleAppNames;
        foreach (var ruleApp in directories.RuleApps)
        {
            foreach (var ruleAppDef in from ruleAppName in ruleAppNames
                     where ruleApp.Name.Contains(ruleAppName)
                     select ruleApp.FullName
                     into ruleAppFile
                     select new FileSystemRuleApplicationReference(ruleAppFile)
                     into ruleAppRef
                     select ruleAppRef.GetRuleApplicationDef())
            {

                var LocalEncoding = Encoding.UTF8;
                var templateEngine = new TemplateEngine();
                //var startTime = DateTime.UtcNow;

                templateEngine.LoadRuleApplication(ruleAppDef);
                templateEngine.LoadStandardTemplateCatalog();
                var fileInfo = RuleAppReport.RunRuleAppReport(ruleAppDef, templateEngine);
                templateEngine.Dispose();
                var inputFile = new FileStream(fileInfo.FullName, FileMode.Open, FileAccess.Read);
                //var base64Stream = new CryptoStream(inputFile, new ToBase64Transform(), CryptoStreamMode.Read);
                var mem = new MemoryStream(File.ReadAllBytes(fileInfo.FullName));
                inputFile.Dispose();
                var ruleReport = LocalEncoding.GetString(mem.ToArray());
                mem.Dispose();
            }
        }
    }

    #endregion

    #region TestAonCode

    public void TestAonCode()
    {
        var directories = GetFiles(true, true);
        var ruleAppFiles = directories.RuleApps;
        var xmlFiles = directories.XmlFiles;
        var ruleAppNames = AppSettings.RuleAppNames;
        var ruleSets = AppSettings.RuleSets;
        var fileDates = AppSettings.FileDates;
        foreach (var ruleApp in ruleAppFiles.Where(ruleApp => ruleApp.FullName.Contains("ruleappx")))
        {
            foreach (var xmlFile in ruleAppNames.SelectMany(ruleAppName => fileDates.SelectMany(fileDate => xmlFiles.Where(xmlFile =>
                         xmlFile.Name.Contains("Validated") &&
                         xmlFile.Name.Contains(ruleAppName) //&& xmlFile.Name.Contains(ruleSet) 
                         && xmlFile.Name.Contains(fileDate)))))
            {
                //ExecuteRuleSetByXPath(xmlFile.FullName, ruleApp.FullName);
                GetXPathEntityModel(xmlFile.FullName, ruleApp.FullName);
            }
        }
        var xpathT = "/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/DO_PRIOR_CLAIMS";
    }
    private async Task GetXPathEntityModel(string inputXmlFile, string ruleAppFile)
    {
        var Model = new XPathEntityModel();
        var ruleAppRef = new FileSystemRuleApplicationReference(ruleAppFile);
        var scenario1 = false;
        var scenario2 = false;
        var scenario3 = true;
        try
        {
            if (scenario1)
            {
                using var session = new RuleSession(ruleAppRef);
                var xmlDoc = new XmlDocument();
                xmlDoc.Load(inputXmlFile);
                var innerXml = xmlDoc.InnerXml;
                var entity = session.CreateEntity("POLICY", innerXml, EntityStateType.Xml);
                await session.ApplyRulesAsync();
                var TOTAL_PREMIUM1 = entity.GetElement("/POLICY/POLICY_AFF_DNO[1]/TOTAL_PREMIUM").ToString();
                var LIMIT1 = entity.GetElement("/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/LIMIT").ToString();
                var xpath = "/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/LIMIT";
                xpath = xpath.StartsWith("/POLICY/")
                    ? xpath.Replace("/POLICY/", "/")
                    : xpath.Replace("POLICY/", "/"); // You want less of these
                var xpathRS = "/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/doepl_Do_Limit";
                var indexRS1 = xpathRS.LastIndexOf("/", StringComparison.Ordinal) + 1;
                var indexRS2 = xpathRS.Length - indexRS1;
                var newXpathRS = xpathRS.Substring(indexRS1, indexRS2);

                Model.ItemName = xpath[(xpath.LastIndexOf("/", StringComparison.Ordinal) + 1)..];
                Model.Entity = session.GetEntity(session
                    .GetElement(entity.ElementId + xpath[..xpath.LastIndexOf("/", StringComparison.Ordinal)])
                    .ToString());
                Model.Entity.Fields[Model.ItemName].Value = "2000000";
                await Model.Entity.ExecuteRuleSetAsync(newXpathRS);

                var TOTAL_PREMIUM2 = entity.GetElement("/POLICY/POLICY_AFF_DNO[1]/TOTAL_PREMIUM").ToString();
                var LIMIT2 = entity.GetElement("/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/LIMIT").ToString();
                string str = "";
            }
            if (scenario2)
            {
                using var session = new RuleSession(ruleAppRef);
                var xmlDoc = new XmlDocument();
                xmlDoc.Load(inputXmlFile);
                var innerXml = xmlDoc.InnerXml;
                var entity = session.CreateEntity("POLICY", innerXml, EntityStateType.Xml);
                await session.ApplyRulesAsync();
                //var TOTAL_PREMIUM1 = entity.GetElement("/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/DO_PRIOR_CLAIMS").ToString();
                //var LIMIT1 = entity.GetElement("/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/LIMIT").ToString();
                var xpath = "/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/DO_PRIOR_CLAIMS";
                xpath = xpath.StartsWith("/POLICY/")
                    ? xpath.Replace("/POLICY/", "/")
                    : xpath.Replace("POLICY/", "/"); // You want less of these
                var xpathRS = "/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/doepl_Do_Limit";
                var indexRS1 = xpathRS.LastIndexOf("/", StringComparison.Ordinal) + 1;
                var indexRS2 = xpathRS.Length - indexRS1;
                var newXpathRS = xpathRS.Substring(indexRS1, indexRS2);

                Model.ItemName = xpath[(xpath.LastIndexOf("/", StringComparison.Ordinal) + 1)..];
                Model.Entity = session.GetEntity(session
                    .GetElement(entity.ElementId + xpath[..xpath.LastIndexOf("/", StringComparison.Ordinal)])
                    .ToString());
                Model.Entity.Fields[Model.ItemName].Value = "Material";
                
                await Model.Entity.ExecuteRuleSetAsync(newXpathRS);
                
                string str = "";
            }
            if (scenario3)
            {
                m_session = new RuleSession(ruleAppRef);
                var xmlDoc = new XmlDocument();
                xmlDoc.Load(inputXmlFile);
                var innerXml = xmlDoc.InnerXml;
                m_entity = m_session.CreateEntity("POLICY", innerXml, EntityStateType.Xml);
                await m_session.ApplyRulesAsync();
                var xpath = "/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/DO_PRIOR_CLAIMS";
                var xpathRS = "/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/doepl_Do_Limit";

                SetValue(xpath, "Material");
                var getValue1 = m_entity.GetElement(xpath).ToString();
                var getValue3 = GetField(xpath);

                await ExecuteRuleSetMethod(xpathRS[(xpathRS.LastIndexOf("/") + 1)..]);
                
                var stopCheck = "";
            }
        }
        catch (Exception e)
        {
            Log.Logger.Error("Error: {e}", e);
        }
    }
    public string GetField(string xpath)
    {
        return m_entity.GetElement(xpath).ToString();
    }
    public void SetValue(string xpath, dynamic value)
    {
        m_model.ItemName = xpath[(xpath.LastIndexOf("/") + 1)..];
        m_model.Entity = m_session.GetEntity(m_session.GetElement(m_entity.ElementId + xpath[..xpath.LastIndexOf("/")]).ToString());
        m_model.Entity.Fields[m_model.ItemName].Value = value;
    }
    public async Task ExecuteRuleSetMethod(string xpathRS)
    {
        await m_model.Entity.ExecuteRuleSetAsync(xpathRS[(xpathRS.LastIndexOf("/", StringComparison.Ordinal) + 1)..]);
    }
    //public string GetValue(string xpath)
    //{
    //    // InRuleField model = new InRuleField();
    //    m_model.ItemName = xpath[(xpath.LastIndexOf("/") + 1)..];
    //    m_model.Entity = m_session.GetEntity(m_session.GetElement(m_entity.ElementId + xpath[..xpath.LastIndexOf("/")]).ToString());
    //    return m_model.Entity.Fields[m_model.ItemName].Value.ToString();
    //}

    //public void ExecuteRuleSetByXPath(string inputXmlFile, string ruleAppFile)
    //{
    //    var ruleAppRef = new FileSystemRuleApplicationReference(ruleAppFile);
    //    try
    //    {
    //        using var session = new RuleSession(ruleAppRef);
    //        var xmlDoc = new XmlDocument();
    //        xmlDoc.Load(inputXmlFile);
    //        var innerXml = xmlDoc.InnerXml;
    //        var entity = session.CreateEntity("POLICY", innerXml, EntityStateType.Xml);
    //        //var xpath = "/POLICY/doepl_Do_LimitNew";
    //        var xpath = "/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/doepl_Do_Limit";
    //        entity.ExecuteRuleSet("doepl_Do_LimitNew");
    //        var POLICY_AFF_DNO_DOEPL = entity.GetElement("/POLICY/POLICY_AFF_DNO[1]/POLICY_AFF_DNO_DOEPL/LIMIT");

    //        SetValue(ruleAppFile, xpath, innerXml, true);

    //        var policy = new POLICY
    //        {
    //            POLICYAFFDNO = new POLICYAFFDNO
    //            {
    //                POLICYAFFDNODOEPL = new POLICYAFFDNODOEPL()
    //                {
    //                    LIMIT = 2000000
    //                }
    //            }
    //        };
    //        var newLimit = policy.POLICYAFFDNO.POLICYAFFDNODOEPL.LIMIT;

    //        var POLICY_AFF_DNO_Collection = entity.Collections["POLICY_AFF_DNO"];
    //        foreach (var field in POLICY_AFF_DNO_Collection)
    //        {
    //            // Get existing limit by object reference
    //            var limit1 = field.Fields["POLICY_AFF_DNO_DOEPL"].Fields["LIMIT"];


    //            Log.Logger.Information("POLICY_AFF_DNO_DOEPL - LIMIT existing is: {limit1}", limit1);

    //            // Set new limit value
    //            field.Fields["POLICY_AFF_DNO_DOEPL"].Fields["LIMIT"].SetValue(newLimit);

    //            // Confirm new limit value is set
    //            var limit2 = field.Fields["POLICY_AFF_DNO_DOEPL"].Fields["LIMIT"];
    //            Log.Logger.Information("POLICY_AFF_DNO_DOEPL - New LIMIT is now: {limit2}", limit2);
    //            entity.ExecuteRuleSet("doepl_Do_LimitNew");
    //        }

    //    }
    //    catch (Exception ex)
    //    {
    //        Log.Logger.Information("Error: {ex}", ex);
    //    }

    //}


    private void Process(Action action, [CallerMemberName] string memberName = "")
    {
        try
        {
            action.Invoke();
        }
        catch (InRuleException inRuleEx)
        {
            throw inRuleEx;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public class InRuleException : Exception
    {
        public InRuleException() { }
        public InRuleException(string message) : base(message) { }
        public InRuleException(string message, Exception innerException) : base(message, innerException) { }
    }
    public void SetValue(string ruleAppFile, string XPath, string innerXml, dynamic Value)
    {
        var ruleAppRef = new FileSystemRuleApplicationReference(ruleAppFile);
        try
        {
            using var session = new RuleSession(ruleAppRef);
            var entity = session.CreateEntity("POLICY", innerXml, EntityStateType.Xml);
            var inputXML = entity.GetXml();
            var xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(inputXML);
            XPath = HttpUtility.UrlDecode(XPath);
            XPathNavigator nav = xmlDoc.CreateNavigator().SelectSingleNode(XPath);
            if (Value is bool)
            {
                nav.SetValue(Value == true ? "1" : "0");
            }
            else
            {
                Value = ConvertToValidDataFormat(Value.ToString());
                nav.SetValue(Value.ToString());
            }

            entity.ParseXml(xmlDoc.InnerXml);

        }
        catch (Exception e)
        {
           
        }
    }
    public abstract class InRuleDomainBase<TIRuleapp>
    {
        private TIRuleapp _ruleapp;

        protected TIRuleapp Ruleapp
        {
            get { return _ruleapp; }
        }

        public InRuleDomainBase() { }

        public InRuleDomainBase(TIRuleapp ruleapp)
        {
            _ruleapp = ruleapp;
        }
    }
    //public void ExecuteRuleSetByXPath(string RuleSetPath)
    //{
    //    try
    //    {
    //        m_Entity.ExecuteRuleSet(RuleSetPath);
    //    }
    //    catch (Exception e)
    //    {
    //        throw new InRuleSessionException("ExecuteRuleSetByXPath Error: " + e.ToString());
    //    }
    //}    
    private static XmlNodeList ReplaceXmlData(XmlNodeList xmlNodeList)
    {
        foreach (XmlNode node in xmlNodeList)
        {
            if (node.HasChildNodes)
                ReplaceXmlData(node.ChildNodes);
            else
            {
                // get values after a decimal
                if (node.InnerText.Contains("."))
                {
                    var substring = node.InnerText[(node.InnerText.LastIndexOf(".") + 1)..];
                    var substringZ = "." + substring;
                    var isAllZeros = substring
                        .Where(char.IsDigit)
                        .All(x => x == '0');

                    if (!isAllZeros) continue;
                    node.InnerText = node.InnerText.Replace(substringZ, "");
                }
                else
                {
                    node.InnerText = ConvertToValidDataFormat(node.InnerText);
                }
            }
        }

        return xmlNodeList;
    }

    public static string ConvertToValidDataFormat(string inputValue)
    {
        inputValue = HttpUtility.UrlDecode(inputValue);
        if (DateTime.TryParse(inputValue, out var timeFound) && !inputValue.Contains("."))
        {
            inputValue = timeFound.ToString("yyyy-MM-dd");
            return inputValue;
        }
        if (inputValue.Contains("."))
        {
            var substring = inputValue[(inputValue.LastIndexOf(".") + 1)..];
            var substringZ = "." + substring;
            var isAllZeros = substring
                .Where(char.IsDigit)
                .All(x => x == '0');

            if (isAllZeros)
            {
                inputValue = inputValue.Replace(substringZ, "");
            }
        }
        return inputValue;
    }




    //private void CleanupDateTypeFields(string xPath)
    //{
    //    XmlNodeList xmlDateNodes = _initializationXml.SelectNodes(xPath);

    //    foreach (XmlNode xmlNode in xmlDateNodes)
    //    {
    //        DateTime timeFound;

    //        if (DateTime.TryParse(xmlNode.InnerText, out timeFound))
    //        {
    //            xmlNode.InnerText = timeFound.ToString("yyyy-MM-dd");
    //        }
    //    }
    //}

    //private void CleanupIntegerTypeFields(string xPath)
    //{
    //    XmlNodeList xmlIntegerNodes = _initializationXml.SelectNodes(xPath);

    //    foreach (XmlNode xmlNode in xmlIntegerNodes)
    //    {
    //        xmlNode.InnerText = (xmlNode.InnerText.IndexOf(".") == -1
    //            ? xmlNode.InnerText : xmlNode.InnerText.Substring(0, xmlNode.InnerText.IndexOf(".")));
    //    }
    //}
    private class XPathEntityModel
    {
        public Entity Entity { get; set; }

        public string ItemName { get; set; }
    }

    internal static EntityModel FromDef(EntityDef x)
    {
        return new EntityModel
        {
            Name = x.Name,
            Fields = x.Fields.AsEnumerable<FieldDef>()
                .Select(fd => new EntityFieldModel
                {
                    Name = fd.Name,
                    DataType = fd.IsAnEntityDataType ? fd.DataTypeEntityName : fd.DataType.GetDisplayText(),
                    FieldType = fd.FieldDefType.ToString()
                }).ToList(),
            RuleSets = x.GetAllRuleSets(true)
                .Select(rs => new RuleSetModel
                {
                    Name = rs.Name,
                    FireMode = rs.FireMode.ToString(),
                    RunMode = rs.RunMode.ToString(),
                    IsEnabled = rs.IsActive,
                    Parameters = GetRuleSetParms(rs)
                }).ToList()
        };
    }

    private static IEnumerable<RuleSetParmModel> GetRuleSetParms(RuleSetDef rs)
    {
        if (!((IEnumerable<RuleSetParameterDef>)rs.Parameters).Any())
        {
            return null;
        }

        var list = new List<RuleSetParmModel>();
        foreach (RuleSetParameterDef rsParm in rs.Parameters)
        {
            list.Add(new RuleSetParmModel
            {
                Name = rsParm.Name,
                DataType = rsParm.DataType.ToString(),
                IsEntityDataType = rsParm.IsAnEntityDataType,
                DataTypeEntityName = rsParm.DataTypeEntityName
            });
        }

        return list;
    }
    public IEnumerable<EntityModel> Entities { get; set; }
    public class EntityModel
    {
        public string Name { get; set; }
        public IEnumerable<EntityFieldModel> Fields { get; set; }

        public IEnumerable<RuleSetModel> RuleSets { get; set; }

    }
    public class EntityFieldModel
    {
        public string Name { get; set; }
        public string DataType { get; set; }
        public string FieldType { get; set; }
    }

    public class RuleSetModel
    {
        public string Name { get; set; }
        public string FireMode { get; set; }
        public bool IsEnabled { get; set; }
        public string RunMode { get; set; }

        public IEnumerable<RuleSetParmModel> Parameters { get; set; }
    }
    public class RuleSetParmModel
    {
        public string Name { get; set; }
        public string DataType { get; set; }
        public bool IsEntityDataType { get; set; }
        public string DataTypeEntityName { get; set; }
        public string Value { get; set; }
    }
    #endregion

    public class InRuleField
    {
        private InRuleFieldType _type = InRuleFieldType.Text;
        public string XPath { get; set; }

        public List<InRuleFieldAttribute> Attributes = new List<InRuleFieldAttribute>();

        public string Name { get; set; }

        public string DisplayName { get; set; }

        public InRuleFieldType Type
        {
            get { return _type; }
            set { _type = value; }
        }

        public string DefaultValue { get; set; }

        public object Value { get; set; }
    }


    public class InRuleFieldAttribute
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }


    public enum InRuleFieldType
    {
        Boolean,
        Complex,
        Date,
        DateTime,
        Decimal,
        Entity,
        Integer,
        Text
    }


    //var result = newXpath?.Split('/').ToList();
    //string[]? xpathElements = newXpath?.Split("/");
    //var fields = new List<string>();

    //var runningCount = 0;
    //Collection collectionW = null;
    //Entity entityW = null;
    ////for(var i = 0; i < xpathElements.Length; i++)
    //foreach (var field in xpathElements)
    //{
    //    if (field == "POLICY")
    //        fields.Add(field);
    //    else
    //    {
    //        if (!entity.Collections.Any())
    //        {
    //            entityW = session.GetEntity(field);
    //            var check = "";
    //        }
    //        else
    //        {
    //            foreach (var t in entity.Collections)
    //            {
    //                if (!field.Contains(t.Name)) continue;
    //                collectionW = t;
    //                var check = "";
    //                break;
    //            }
    //        }
    //    }
    //    runningCount++;
    //}
}
