﻿
using System.Xml;
using InRule.Runtime;
using SDKRunner573.Models;
using Serilog;

namespace SDKRunner29;

public interface IRunSdk
{
    void Start();
}

public class RunSDK29 : IRunSdk
{
    private static readonly AppSettings AppSettings = Program.AppSettings;
    private bool _runRules = false;

    public void Start()
    {
        //ValidateXMLFiles();
        SendFilesToSDK();
        //PullRuleSets();
        //ValidateXml
    }

    public void SendFilesToSDK()
    {
        var directories = GetFiles(true, true);
        var ruleAppFiles = directories.RuleApps;
        var xmlFiles = directories.XmlFiles;

        var ruleAppNames = AppSettings.RuleAppNames;
        var ruleSets = AppSettings.RuleSets;
        var entityNames = AppSettings.EntityNames;
        var fileDates = AppSettings.FileDates;

        foreach (var ruleApp in ruleAppFiles)
        {
            foreach (var ruleAppName in ruleAppNames.Where(ruleAppName => ruleApp.Name.Contains(ruleAppName)))
            {
                foreach (var ruleSet in ruleSets)
                {
                    foreach (var entityName in entityNames)
                    {
                        foreach (var fileDate in fileDates)
                        {
                            foreach (var xmlFile in xmlFiles.Where(xmlFile
                                         => xmlFile.Name.Contains("_Validated")
                                            && xmlFile.Name.Contains(ruleAppName)
                                            && xmlFile.Name.Contains(ruleSet)
                                            && xmlFile.Name.Contains(ruleSet)
                                            && xmlFile.Name.Contains(fileDate)))
                            {
                                var ruleAppFile = ruleApp.FullName;
                                var inputXmlFile = xmlFile.FullName;
                                Log.Logger.Information("Running 2.9 SDK with the following parameters:");
                                Log.Logger.Information("EntityName: {entityName}", entityName);
                                Log.Logger.Information("RuleSet: {ruleSet}", ruleSet);
                                Log.Logger.Information("InputXmlFile: {inputXmlFile}", inputXmlFile);
                                Log.Logger.Information("RuleAppFile: {ruleAppFile}", ruleAppFile);
                                Log.Logger.Information("");

                                var outputFile = RunSdk29(entityName, ruleSet, inputXmlFile, ruleAppFile);
                            }
                        }
                    }
                }
            }
        }
    }

    public void ValidateXmlFiles()
    {
        var directories = GetFiles(true, false);
        var entityNames = AppSettings.EntityNames;
        var xmlFiles = directories.XmlFiles;
        foreach (var entityName in entityNames)
        {
            foreach (var xmlFile in xmlFiles.Where(xmlFile
                         => xmlFile.Name.Contains("Input")
                            && xmlFile.Name.Contains(entityName)))
            {
                var changeRequired = false;
                var xmlDoc = new XmlDocument();
                xmlDoc.Load(xmlFile.FullName);
                var dataNodes = xmlDoc.SelectNodes($"//{entityName}");
                foreach (XmlNode xmlNode in dataNodes)
                {
                    foreach (XmlNode childNode in xmlNode.ChildNodes)
                    {
                        if (!childNode.InnerText.Contains("."))
                        {
                            DateTime timeFound;
                            if (DateTime.TryParse(childNode.InnerText, out timeFound))
                            {
                                childNode.InnerText = timeFound.ToString("yyyy-MM-dd");
                                changeRequired = true;
                                continue;
                            }
                        }

                        if (!childNode.InnerText.Contains(".") && !childNode.InnerText.Any(char.IsDigit)) continue;
                        var valueAfterDecimal = childNode.InnerText[(childNode.InnerText.LastIndexOf('.') + 1)..];
                        if (!valueAfterDecimal.Any("123456789".Contains))
                        {
                            changeRequired = true;
                            childNode.InnerText = valueAfterDecimal.Replace(valueAfterDecimal, "").Replace(".", "");
                            if (childNode.InnerText == "")
                                childNode.InnerText = "0";
                        }
                    }
                }

                if (!changeRequired) return;
                Log.Logger.Information($"{xmlFile.Name} required date validation");
                var outputFile = xmlFile.FullName.Replace(".xml", "") + "_Validated.xml";
                if (File.Exists(outputFile))
                    File.Delete(outputFile);
                File.WriteAllText(outputFile, xmlDoc.OuterXml);
                Log.Logger.Information($"{outputFile} was written");

            }
        }        
    }


    public OutputXmlClass RunSdk29(string entityName, string ruleSet, string inputXmlFile, string ruleAppFile)
    {
        var inputFileName = inputXmlFile[(inputXmlFile.LastIndexOf('/') + 1)..].Replace(".xml", "").Replace("Input", "").Replace("_Validated", "");
        var outputFile = inputFileName + "_v573_Output.xml";
        //var ruleAppRef = new FileSystemRuleApp(ruleAppFile);
        var outputXml = new OutputXmlClass();
        try
        {
            using var session = new RuleSession(new FileSystemRuleApp(ruleAppFile), new InProcessConnection());            

            var xmlDoc = new XmlDocument();
            xmlDoc.Load(inputXmlFile);
            var innerXml = xmlDoc.InnerXml;
            var entity = session.CreateEntity(entityName);
            entity.State.LoadXml(innerXml);

            switch (ruleSet)
            {
                case "AutoRuleSet":
                    session.ApplyRules();
                    break;
                default:
                    entity.ExecuteRuleSet(ruleSet);
                    break;
            }
            
            outputXml.OutputXml = entity.State.GetXml();
            outputXml.OutputXmlFileName = outputFile;
            //var finalEntityStateXml = new XmlDocument();
            //finalEntityStateXml.LoadXml(finalEntityState);
            //innerEntityXml = finalEntityStateXml.InnerXml;

            if (File.Exists(outputXml.OutputXmlFileName))
                File.Delete(outputXml.OutputXmlFileName);
            File.WriteAllText(outputXml.OutputXmlFileName, outputXml.OutputXml);
            Log.Logger.Information("Executed rules and created result file named {outputFile}", outputFile);
        }
        catch (Exception ex)
        {
            Log.Logger.Information($"ERROR with entityName: {entityName} ruleSet:{ruleSet} inputXmlFile:{inputXmlFile} ruleAppFile: {ruleAppFile}: {ex.Message}");
            outputFile = "";
            inputFileName = inputXmlFile.Replace(".xml", "").Replace("Input", "");
            var errorFile = inputFileName + " " + ruleSet + "_ErrorFile.txt";
            if (File.Exists(errorFile))
                File.Delete(errorFile);
            File.WriteAllText(errorFile, ex.Message);
        }
        return outputXml;
    }

    public Directories GetFiles(bool ruleApps, bool xmlFiles)
    {
        var directories = new Directories();
        if (ruleApps)
        {
            var ruleAppDirectory = new DirectoryInfo(AppSettings.RuleAppPath);
            directories.RuleApps = ruleAppDirectory.GetFiles("*.ruleappx*");
        }

        if (xmlFiles != true) return directories;
        var xmlFileDirectory = new DirectoryInfo(AppSettings.XmlFilePath);
        directories.XmlFiles = xmlFileDirectory.GetFiles("*.xml*");

        return directories;
    }
}
