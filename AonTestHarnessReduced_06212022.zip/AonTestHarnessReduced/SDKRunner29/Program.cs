﻿using System.ComponentModel.DataAnnotations;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SDKRunner573.Models;
using Serilog;

namespace SDKRunner29;
internal class Program
{
    public static AppSettings AppSettings { get; private set; }

    private static void Main()
    {
        //var builder = new ConfigurationBuilder();
        //    BuildConfig(builder);
        var config = new ConfigurationBuilder().AddJsonFile("appsettings.json", false, true);

        var builder = config.Build();
        AppSettings = builder.GetSection("AppSettings").Get<AppSettings>();

        if (!Validator.TryValidateObject(AppSettings, new ValidationContext(AppSettings),
                    new List<ValidationResult>(), true))
        {
            throw new Exception("Appsettings is missing required fields");
        }


        //Console.WriteLine(appSettings.ThreadCount);

        var host = Host.CreateDefaultBuilder()
            //.ConfigureHostConfiguration(hostConfig =>
            //    {
            //        hostConfig.SetBasePath(Directory.GetCurrentDirectory());
            //        hostConfig.AddJsonFile("hostsettings.json", optional: true);
            //        hostConfig.AddEnvironmentVariables(prefix: "PREFIX_");
            //        hostConfig.AddCommandLine(args);
            //    });
            .ConfigureServices((context, services) =>
            {
                services.AddTransient<IRunSdk, RunSDK29>();
            })
            .UseSerilog()
            .Build();

        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(config.Build())
            .Enrich.FromLogContext()
            .WriteTo.File(AppSettings.LogFilePath, rollingInterval: RollingInterval.Day)
            .WriteTo.Console()
            .CreateLogger();



        var startTime = DateTime.UtcNow;
        Log.Logger.Information($"Application Started {startTime}");
        var svc = ActivatorUtilities.CreateInstance<RunSDK29>(host.Services);
        svc.Start();

        var elapsedTime = Math.Round(((DateTime.UtcNow - startTime).TotalMinutes), 2);
        Log.Logger.Information($"Application Ended: {DateTime.UtcNow} elapsed time: {elapsedTime} minutes.");
    }

    //private static void BuildConfig(IConfigurationBuilder builder)
    //{
    //    builder.SetBasePath(Directory.GetCurrentDirectory())
    //        .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

    //}
}
